rm(list=ls())


setwd(dirname(rstudioapi::getSourceEditorContext()$path))


load('input/XSAMdata.RDa')
load('model/XSAMfit.Rda')
library(TMB)
source('bootstrap/utils/utils.r')
source('bootstrap/XSAMmodel/constrains.r')


XSAMsettings<-ReadXSAMsettings("bootstrap/XSAMmodel/model.txt")
StartValFixed=XSAMfit$optobj$par
n<-5
XSAMsettings$UseCatchPred<-0
control=list(iter.max=500,eval.max=500)


pars<-CreateParameterList(data,mapnames=NULL)



compile('bootstrap/XSAMmodel/XSAM.cpp')
dyn.load(dynlib('bootstrap/XSAMmodel/XSAM'))

# FitXSAMFunction(data,pars,constraints=constraints,control=control)




#filter out data
data$caa<-data$caa[-nrow(data$caa),]

data$years<-data$years[-length(data$years)]
data$noYears<-data$noYears-1


data$CatchPrediction['Prediction']<-as.numeric(data$caton[length(data$caton)])
data$caton<-data$caton[-length(data$caton)]


asdf

# data$years<-data$years[-length(data$years)]
# data$noYears<-data$noYears-1

data$caa[31,]<--999

pars<-CreateParameterList(data,mapnames=NULL)
fit2<-FitXSAMFunction(data,pars,constraints=constraints,control=control)

plot(XSAMfit$stats$ssb,type='l')
lines(fit2$stats$ssb)



################################
RunXSAMRetro<-function(XSAMdatalist,XSAMsettings,n,constraints=NULL,control=NULL,sdlist=NULL,StartValFixed=NULL){
  startyear<-XSAMsettings$yearrange[2]
  fits<-list()
  for(i in 0:n){
    assessmentyear<-startyear-i
    print(assessmentyear)
    XSAMsettings$yearrange[2]<-assessmentyear
    if(i>0)XSAMdatalist$caa[paste(assessmentyear),]<--999#NA
    #print(XSAMdatalist$caa)
    #stop()
    dataobj<-CreateDataObject(settings=XSAMsettings,datalist=XSAMdatalist)
    if(!is.null(sdlist)){
      tmp<-sdlist[[1]]
      tmp<-tmp[,1:ncol(dataobj$sd_C)]
      tmp[,ncol(dataobj$sd_C)]<-tmp[,ncol(dataobj$sd_C)-1]
      dataobj$sd_C<-as.matrix(tmp)
      for(j in 2:length(XSAMsettings$fleetIndex)){
        tmp<-sdlist[[j]]
        tmp<-tmp[,1:ncol(dataobj$sd_I[,,j-1])]
        dataobj$sd_I[,,j-1]<-tmp
      }
    }
    dataobj$caa[dataobj$caa<0]<--999
    pars<-CreateParameterList(dataobj,mapnames=NULL)
    if(!is.null(StartValFixed)) pars$ParameterList$FixedPars[pars$ParameterNames%in%pars$ParameterNames[!is.na(pars$MapVector)]]<-StartValFixed
    if(is.null(constraints) & is.null(control))fits[[i+1]]<-FitXSAMFunction(dataobj,pars)
    if(!is.null(constraints) & is.null(control))fits[[i+1]]<-FitXSAMFunction(dataobj,pars,constraints=constraints)
    if(is.null(constraints) & !is.null(control))fits[[i+1]]<-FitXSAMFunction(dataobj,pars,control=control)
    if(!is.null(constraints) & !is.null(control))fits[[i+1]]<-FitXSAMFunction(dataobj,pars,constraints=constraints,control=control)
  }
  fits
}
