#This script reads the stox outputs and generates 2 sets of files: 
#   The fleet file
#   The raw variance from fleet file





rm(list=ls())

library(httr)
GET("https://raw.githubusercontent.com/ices-taf/2020_her.27.1-24a514a_acousticIndex_NORHERSS/master/2019/output/r/r.R?token=AEZO6L46Y6DL6G27T2AQ7KC6IZWAE")


readFleetFromTAF <- function(path=NULL, surveys = NULL){
  
  
  #Internal path to stox file
  stox_path = '/output/r/report/bootstrapImpute_Abundance_age.txt'
  
  
  #For output
  stox.output = c()
  
  
  for(survey in surveys){
    
    #Grab all years
    years <- list.dirs(paste0(dir,'/',survey),recursive = FALSE,full.names = FALSE)
    
    
    
    #For output
    stox.output$tmp = c()
    stox.output$tmp = c()
    attr(stox.output$tmp,'time') <- NULL
    attr(stox.output$tmp,'age') <- NULL
    
    
    
    for (year in years){
      #Make the path of the stox file
      stox.file <- paste0(dir,'/',survey,'/',year,stox_path)
      
      
      #read data and set year
      tab <- read.table(stox.file,skip = 9,header = TRUE)
      
      
      #Test to see if the fil format is correct
      if(names(tab)[1]!='age'){
        print('error in data format')
        break
      }
      
      
      #Grab number of observations
      nboot <- strsplit(readLines(stox.file)[5],':')
      if (nboot[[1]][1] !='nboot'){
        print('error in data format for nboot')
        break}
      nboot<-as.numeric(nboot[[1]][2])
      
      
      #Check if the scaling is ok
      if(strsplit(readLines(stox.file)[2],':')[[1]][2]!=' millions'){
        print(strsplit(readLines(stox.file)[2],':')[[1]][2])
        print('Error in data format for units')
        break
      }
      
      
      #Fixing the scaling and variance
      #Need to check if this is OK
      tab[,2:5]<-tab[,2:5]*1000
      tab[,6]<-sqrt((tab[,6]^2)*(1000^2))
      tab$year <- year
      tab$var <- tab$Ab.Sum.sd^2
      
      
      stox.output$tmp <- rbind(stox.output$tmp,tab)
      attr(stox.output,'age') <- range(tab$age,na.rm = T)
    }
    
    
    #Switch name of the survey
    names(stox.output)[which(names(stox.output)=='tmp')]<-survey
  }
  
    
  # return the output
  return(stox.output)
}




write.ices.survey <- function(fileout,Fleet){
  
  
  
  write(paste0(fileout, paste0(" auto written\n10",length(Fleet))), fileout)
  
  for(x in 1:length(Fleet)){
    write(names(Fleet[x]),fileout, append = TRUE)
    if(dim(Fleet[[x]])[1]==1){
      write(paste0(paste0(range(as.integer(colnames(Fleet[[x]]))), collapse = "  ")), fileout,append = TRUE)
    }
    else{
      write(paste0(paste0(range(as.integer(rownames(Fleet[[x]]))), collapse = "  ")), fileout,append = TRUE)
    }
    #Write from attributes
    write(paste0(c(1,1,attributes(Fleet[[x]])$time),collapse = " "),fileout,append=TRUE,sep="\t")
    write(paste0(attributes(Fleet[[x]])$age, collapse = "  "), fileout,append = TRUE)
    
    
    if(dim(Fleet[[x]])[1]==1){
      write(rbind(1,round((Fleet[[x]]),digits = 3)), fileout, ncolumns = 2, append = TRUE, 
                                    sep = "  \t")}
    else{
      write(rbind(1,round(t(Fleet[[x]]),digits = 3)), fileout, ncolumns = ncol(Fleet[[x]])+1, append = TRUE, 
            sep = "  \t")
    }
  }
}



convertStox2ices<-function(data,maxage=12,minage=3,plsgrp=TRUE){
  
  #Convert to dataframe
  tmp <- as.data.frame(data)
  
  #Make an output matrix
  t <- matrix(-1,nrow = length(sort(unique(tmp$age))),ncol = length(min(unique(tmp$year)):max(unique(tmp$year))))
  rownames(t)<-sort(unique(tmp$age))
  colnames(t)<-min(unique(tmp$year)):max(unique(tmp$year))
  
  
  for(y in 1:nrow(tmp)){
    t[which(rownames(t)==tmp[y,]$age),which(colnames(t)==tmp[y,]$year)] <- tmp[y,]$Ab.Sum.mean/1000000
  }
  for(i in 1:ncol(t)){
    if(sum(t[,i]>=0)>0){
      t[t[,i]==-1,i]<-0
    }
  }
  
  
  pluss <- colSums(t[which(rownames(t)==maxage):nrow(t),])
  t<-t[which(rownames(t)==minage):nrow(t),]
  t<-t[1:which(rownames(t)==maxage),]
  if(plsgrp==T)t[which(rownames(t)==maxage),]<-pluss
  t[t<0]<--1
  
  attr(t,'age')<-c(minage,maxage)
  return(t(t))
}




smoothVar <- function(tmp_in,tmprep_in,grp_year = NULL, grp_age = NULL, Ages = NULL,UseRaw = F){
  
  taylorvar<-function(alfa,beta,n,k,mu){
    #Function that gives the variance of mu=k*mu' where mu' is Norwegian catches or indices from StoX and alpha and beta is estimated for mu' based on the Taylor variance function
    k^(2-beta)*(alfa/n)*(mu)^beta
  }
  
  if(is.null(grp_year)){
    tmp<-tmp_in
    tmprep<-tmprep_in}else{
    tmp<-tmp_in[paste0(grp_year[1]:grp_year[2]),]
    library(dplyr)
    tmprep<-filter(tmprep_in,year%in%c(grp_year[1]:grp_year[2]))
    }

    
  #user input
  sd_I<-tmp
  tmp[tmp<0]<-NA
  tmprep$i<-NA
  pg<-max(as.numeric(dimnames(tmp)[[2]]))
  tmprep$age<-as.numeric(paste(tmprep$age))
  tmprep<-tmprep[!is.na(tmprep$age),]
  for(i in 1:nrow(tmprep)){
    if(is.null(Ages)){
      if(tmprep$age[i]>=min(as.numeric(dimnames(tmp)[[2]])) & tmprep$age[i]<max(as.numeric(dimnames(tmp)[[2]]))){
        k<-tmp[paste(tmprep$year[i]),paste(tmprep$age[i])]
        if(tmprep$age[i]<pg)tmprep$i[i]<-k
      }
    }else{
      if(tmprep$age[i]>=Ages[1]&tmprep$age[i]<Ages[2]){
        k<-tmp[paste(tmprep$year[i]),paste(tmprep$age[i])]
        tmprep$i[i]<-k
      }}
  }
  
  
  #------------------------------------------------------------------------------#
  #Establish scaling factor; i.e. to match scaling deviations in the two sets
  #------------------------------------------------------------------------------#
  k<-lm(i~-1+Ab.Sum.mean,data=tmprep)
  k<-k$coef[1]
  
  
  #------------------------------------------------------------------------------#
  #Establish alpha and beta in Taylor variance relationship
  #------------------------------------------------------------------------------#
  #Taylor model for variance
  fi<-lm(log(var)~log(Ab.Sum.mean),data=tmprep[tmprep$Ab.Sum.mean>0,])
  ci<-confint(fi)
  library(broom)
  print(tidy(fi))
  # print(fi$coef[2])
  
  #Establish structure of data
  ages<-as.numeric(dimnames(tmp)[[2]])
  years<-as.numeric(dimnames(tmp)[[1]])
  for(y in 1:length(years)){
    for(a in 1:length(ages)){
      mu<-tmp[paste(years[y]),paste(ages[a])]
      if(!is.na(mu)){
        v<-taylorvar(alfa=exp(fi$coef[1]),beta=fi$coef[2],n=1,k=k,mu=mu)
        logv<-log(v/mu^2+1)
        sd_I[y,a]<-sqrt(logv)
        
        tmprep_in[(tmprep_in$age==2)+(tmprep_in$year==1988)]
        }
    }
  }
  
  
  sd_I<-(sd_I**2)
  
  return(sd_I)
  
}




varDiag <- function(tmprep){
  
  int <- c()
  beta <- c()
  beta_u <- c()
  int_u <- c()
  for(year in unique(tmprep$year)){
    fit <- tmprep[tmprep$year==year,]
    fi<-lm(log(var)~log(Ab.Sum.mean),data=fit[fit$Ab.Sum.mean>0,])
    int<-c(int,fi$coefficients[1])
    beta<-c(beta,fi$coefficients[2])
    
    out <- summary(fi)
    beta_u <- c(beta_u,out$coefficients[ , 2][2])
    int_u <- c(int_u,out$coefficients[ , 2][1])
  }
  
  df <- c()
  df$year <- unique(tmprep$year)
  df$point <- beta
  df$se <- beta_u
  df$int <- int
  df$int_u <- int_u
  
  fi<-lm(log(var)~log(Ab.Sum.mean),data=tmprep[tmprep$Ab.Sum.mean>0,])
  
  library(ggplot2)
  print(ggplot(data=as.data.frame(df),aes(x=year,y=point)) + geom_point()+
          geom_errorbar(aes(ymin=point-se, ymax=point+se))+ggtitle('beta')+geom_hline(yintercept=fi$coefficients[2]))
  print(ggplot(data=as.data.frame(df),aes(x=year,y=int)) + geom_point()+
          geom_errorbar(aes(ymin=int-int_u, ymax=int+int_u))+ggtitle('alpha')+geom_hline(yintercept=fi$coefficients[1]))
  
  
  print(ggplot(data=as.data.frame(df),aes(x=point,y=int)) + geom_point()+
          geom_errorbar(aes(ymin=int-int_u, ymax=int+int_u))+ggtitle('alfa/beta')+geom_hline(yintercept=fi$coefficients[1]))
}





setwd(dirname(rstudioapi::getSourceEditorContext()$path))


dir='E:/Arbeid/ICES_TAF/'


#Grab the data from the stox files
dat <- readFleetFromTAF(path = dir,surveys = c('NORHERSS.her','IESNS.ns.her','IESNS.bs.her'))
dat_var <- dat


#Make matrix that can be used in SAM/XSAM model
dat$NORHERSS.her<-convertStox2ices(data = dat$NORHERSS.her,minage = 3,maxage = 12,plsgrp = TRUE)
dat$IESNS.ns.her<-convertStox2ices(data = dat$IESNS.ns.her,minage = 3,maxage = 12,plsgrp = TRUE)
dat$IESNS.bs.her<-convertStox2ices(data = dat$IESNS.bs.her,minage = 2,maxage = 2,plsgrp = FALSE)


#Add data that does not have a stox project
tmp <- matrix(c(4.114,22.461,13.244,4.916,2.045,0.424,0.014,0.007,0.155,3.134,
         1.169,3.599,18.867,13.546,2.473,1.771,0.178,0.077,0.288,2.947,
         0.367,1.099,4.41,16.378,10.16,2.059,0.804,0.183,NA,0.527,
         2.191,0.322,0.965,3.067,11.763,6.077,0.853,0.258,0.005,0.3,
         1.353,2.783,0.092,0.384,1.302,7.194,5.344,1.689,0.271,0.189,
         8.312,1.43,1.463,0.179,0.204,3.215,5.433,1.22,0.094,0.184,
         6.343,9.619,1.418,0.779,0.375,0.847,1.941,2.5,1.423,0.167,
         6.561,9.985,9.961,1.499,0.732,0.146,0.228,1.865,2.359,2.056,
         1.543,5.227,12.571,10.71,1.075,0.58,0.076,0.313,0.362,2.512,
         19.679,1.353,1.765,6.205,5.371,0.651,0.388,0.139,0.262,2.008,
         0.306,14.56,1.396,2.011,6.521,6.978,0.679,0.713,0.173,2.189,
         2.889,5.877,20.292,1.26,1.992,6.78,5.582,0.647,0.488,2.833),nrow=10)
rownames(tmp)<-3:12
colnames(tmp)<-1996:2007
dat$IESNS.ns.her<-rbind(t(tmp),dat$IESNS.ns.her)
attr(dat$IESNS.ns.her,'age')<-c(3,12)
attr(dat$IESNS.ns.her,'time')<-c(0.4167,0.4167)



#Add data that does not have a stox project
tmp <- matrix(c(0.0052,0.014,0.0258,0.0592,0.0077,0.00025,4e-05,0.0047,0.0049,0.0279,0.0076,0.0039,NA,NA,0.0045,0.035,0.0037,0.00038))*1000
colnames(tmp)<-2
rownames(tmp)<-1991:2008
dat$IESNS.bs.her<- cbind(t(tmp),dat$IESNS.bs.her)
attr(dat$IESNS.bs.her,'age')<-c(2,2)
attr(dat$IESNS.bs.her,'time')<-c(0.4167,0.4167)


#add time to data
attr(dat$NORHERSS.her,'time')<-c(0.1667,0.1667)


#Write to a seperate fleet file that can be used in assessment
write.ices.survey(fileout = 'Fleet2.csv',dat)




#Do stuff to the variance


library(stockassessment)

#For testing with old and new
test1 <- read.ices('survey_old.dat')
test2 <- read.ices('Fleet2.csv')
plot(test1$YoungherringintheBarentsSeainMay*1000,test2$IESNS.bs.her,main='old vs new: IESNS.bs.her')
abline(0,1)
plot(c(test1$SpawninggroundsalongtheNorwegiancoast),c(test2$NORHERSS.her),main='old vs new: NORHERSS.her')
abline(0,1)
plot(c(test1$FeedingareasintheNorwegianSeainMay),c(test2$IESNS.ns.her),main='old vs new: IESNS.ns.her')
abline(0,1)











test2$NORHERSS.her<-smoothVar(tmp_in=test2$NORHERSS.her, tmprep_in=dat_var$NORHERSS.her)
test2$IESNS.ns.her<-smoothVar(tmp_in=test2$IESNS.ns.her, tmprep_in=dat_var$IESNS.ns.her)
test2$IESNS.bs.her<-smoothVar(tmp_in=test2$IESNS.bs.her, tmprep_in=dat_var$IESNS.bs.her,Ages=c(2,3))
attr(test2$NORHERSS.her,'age')<-c(3,12)
attr(test2$IESNS.ns.her,'age')<-c(3,12)
attr(test2$IESNS.bs.her,'age')<-c(2,2)
write.ices.survey(fileout = 'Fleet_var.csv',test2)

varS1 = as.matrix(read.table("varS1_old.txt", sep = " "))
varS2 = as.matrix(read.table("varS3_old.txt", sep = " "))
varS3 = as.matrix(read.table("varS2_old.txt", sep = " "))

plot(c(test2$NORHERSS.her),c(varS1),main='old vs new: NORHERSS.her (variance)')
abline(0,1)
plot(c(test2$IESNS.ns.her),c(varS2),main='old vs new: IESNS.ns.her (variance)')
abline(0,1)

plot(c(test2$IESNS.bs.her),c(varS3),main='old vs new: IESNS.bs.her (variance)')
abline(0,1)



#Try splitting between new and old data
test2 <- read.ices('Fleet2.csv')
en<-smoothVar(tmp_in=test2$NORHERSS.her, tmprep_in=dat_var$NORHERSS.her,grp_year = c(1988,2014))
to<-smoothVar(tmp_in=test2$NORHERSS.her, tmprep_in=dat_var$NORHERSS.her,grp_year = c(2015,2019))
test2$NORHERSS.her<-rbind(en,to)
test2$IESNS.ns.her<-smoothVar(tmp_in=test2$IESNS.ns.her, tmprep_in=dat_var$IESNS.ns.her)
test2$IESNS.bs.her<-smoothVar(tmp_in=test2$IESNS.bs.her, tmprep_in=dat_var$IESNS.bs.her,Ages=c(2,3))

attr(test2$NORHERSS.her,'age')<-c(3,12)
attr(test2$IESNS.ns.her,'age')<-c(3,12)
attr(test2$IESNS.bs.her,'age')<-c(2,2)
write.ices.survey(fileout = 'Fleet_var_split.csv',test2)



#Try splitting per year
# test2 <- read.ices('Fleet2.csv')
# for(year in rownames(test2$NORHERSS.her)){
#   print(year)
#   print(smoothVar(tmp_in=test2$NORHERSS.her, tmprep_in=dat_var$NORHERSS.her,grp_year = c(as.integer(year),as.integer(year)+1)))
# }
# 






varDiag(dat_var$NORHERSS.her)
# varDiag(dat_var$IESNS.ns.her)
# varDiag(dat_var$IESNS.bs.her)


eca_rep <- read.csv2('eca.dat')
cn <- read.ices('data/cn.dat')



tmp<-cn
tmprep<-eca_rep
#The ECA point estimates are in the column 'mean'. Add a new column for the 'caa' point estimates used in the modelfitting
#norcaa
tmprep$caa<-NA
maxage<-12
minage<-2

for(i in 1:nrow(tmprep)){
  if(tmprep$alder[i]<maxage & tmprep$alder[i]>=minage)tmprep$caa[i]<-tmp[paste(tmprep$aar[i]),paste(tmprep$alder[i])]
}

  #Compare Norwegian catches vs international totals
  plot(caa~mean,data=tmprep)
  abline(0,1)
  
  #And see that norcaa is~58% of total (in numbers) for ages >=2-11
  tmprep$norwp<-tmprep$cn/tmprep$caa
  mean(tmprep$norwp,na.rm=T)
  #Proportions by age:
  boxplot(norwp~alder,data=tmprep,ylim=c(0,1))
  #Rounding errors can cause proportion>1 for ages 0 and 1; 




#------------------------------------------------------------------------------#
#Establish scaling factor; i.e. from Norwegian to total catches...
#------------------------------------------------------------------------------#
k<-lm(caa~-1+cn,data=tmprep)
k<-k$coef[1]

#------------------------------------------------------------------------------#
#Establish alpha and beta in Taylor variance relationship
#------------------------------------------------------------------------------#
#Taylor model for variance
fcaa<-lm(log(v)~log(mean),data=tmprep)

if(EDA){
  #Add year effect 
  fcaa1<-lm(log(v)~-1+as.factor(aar)+log(mean),data=tmprep)
  AIC(fcaa,fcaa1)
  #And see that adding a year effect yields a significant improvement suggesting different sampling intensities across each year
  #However; to utilize this we would need to expand the model to include international catches and handle years 
  #with noe ECA estimates available!!
  #BUT: the model fit is still good with slopes not significantly different
  summary(fcaa)
  summary(fcaa1)
  
  tmprep$vmod<-exp(fcaa$coef[1])*tmprep$cn^fcaa$coef[2]
  plot(vmod~v,tmprep,log="xy")
  abline(0,1)
}
#OPTIONS:
#1) replace all variances with modelled variances using fcaa (implicitely assuming same effort across years)
#2) replace variance in years with ECA estimates with modelled year specific estimates, and 'average' (from fcaa) for other years
#3) replace variance in years with ECA estimates empirical estimates from ECA, and 'average' (from fcaa) for other years

#HERE: use option 1 becasue 
#1) Norwegian catch is~60% of total and must thus make a prediction ofr the remaining 40%, 
#2) ECA estimates are only available for a limited number of years and must predict the other years
#3) This is probably 'OK' since the model 'fcaa' is good and we later estimate a scaling constant for the variance specified here

#Establish structure of data
sd_C<-cn
ages<-2:12
years<-as.numeric(dimnames(sd_C)[[1]])
for(y in 1:length(years)){
  for(a in 1:length(ages)){
    
    mu<-tmp[paste(years[y]),paste(ages[a])]
    v<-taylorvar(alfa=exp(fcaa$coef[1]),beta=fcaa$coef[2],n=1,k=k,mu=mu)
    logv<-log(v/mu^2+1)
    sd_C[y,a]<-sqrt(logv)
  }
}


write.csv(sd_C,'eca_var.dat')
