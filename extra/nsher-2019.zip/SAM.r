rm(list=ls())
library(stockassessment)

setwd(dirname(rstudioapi::getSourceEditorContext()$path))

#Run standard SAM
cn<-read.ices("bootstrap/init/cn.dat")
cw<-read.ices("bootstrap/init/cw.dat")
dw<-read.ices("bootstrap/init/dw.dat")
lf<-read.ices("bootstrap/init/lf.dat")
lw<-read.ices("bootstrap/init/lw.dat")
mo<-read.ices("bootstrap/init/mo.dat")
nm<-read.ices("bootstrap/init/nm.dat")
pf<-read.ices("bootstrap/init/pf.dat")
pm<-read.ices("bootstrap/init/pm.dat")
sw<-read.ices("bootstrap/init/sw.dat")
surveys<-read.ices("bootstrap/init/Fleet2.csv")
surveys_var<-read.ices("bootstrap/init/Fleet_var.csv")                    #Variance data


#Add variance to attribute
varC = as.matrix(read.table("bootstrap/init/eca_var.dat", sep = ","))
varC<-varC[2:nrow(varC),2:ncol(varC)]^2




#Fix the variance data as this do not have the correct formate
attr(surveys_var[[1]], "time") <- NULL
attr(surveys_var[[2]], "time") <- NULL
attr(surveys_var[[3]], "time") <- NULL
surveys_var[[1]][is.na(surveys_var[[1]])]<-1
surveys_var[[2]][is.na(surveys_var[[2]])]<-1
surveys_var[[3]][is.na(surveys_var[[3]])]<-1


attributes(cn)$weight = 1/(varC)
attributes(surveys[[1]])$weight = 1/(surveys_var[[1]])
attributes(surveys[[2]])$weight = 1/(surveys_var[[2]])
attributes(surveys[[3]])$weight = 1/(surveys_var[[3]])


dat<-setup.sam.data(surveys=surveys,
                    residual.fleet=cn,
                    prop.mature=mo,
                    stock.mean.weight=sw,
                    catch.mean.weight=cw,
                    dis.mean.weight=dw,
                    land.mean.weight=lw,
                    prop.f=pf,
                    prop.m=pm,
                    natural.mortality=nm,
                    land.frac=lf)


conf = loadConf(dat,"bootstrap/SAMmodel/model.cfg")
par<-defpar(dat,conf)
par$logSdLogN = c(-0.35, -5)
map = list(logSdLogN = as.factor(c(0,NA)))
SAMFit<-sam.fit(dat,conf,par,map=map)
# 
save(SAMFit,file = 'model/SAMFit')

ssbplot(SAMFit)
fbarplot(SAMFit)
recplot(SAMFit)

LO<-leaveout(SAMFit)
ssbplot(LO)
