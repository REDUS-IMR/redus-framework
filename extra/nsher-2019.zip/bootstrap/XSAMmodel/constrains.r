


#----------------------------#
#Some constraints
#----------------------------#
constraints<-list()
constraints[[1]]<-list()
constraints[[1]]$par<-"logs2_2"
constraints[[1]]$lower<--5
constraints[[1]]$upper<-Inf

constraints[[2]]<-list()
constraints[[2]]$par<-"logs2_1"
constraints[[2]]$lower<--5
constraints[[2]]$upper<-Inf

constraints[[3]]<-list()
constraints[[3]]$par<-"logs2_4"
constraints[[3]]$lower<--5
constraints[[3]]$upper<-Inf

#These one are not necessary to constrain but...
constraints[[4]]<-list()
constraints[[4]]$par<-"bY"
constraints[[4]]$lower<-0
constraints[[4]]$upper<-1

constraints[[5]]<-list()
constraints[[5]]$par<-"bU"
constraints[[5]]$lower<-0
constraints[[5]]$upper<-1
