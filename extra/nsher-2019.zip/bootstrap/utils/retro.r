

#--------------------------------------------------------#
#RETRO RUN
#--------------------------------------------------------#

load('input/XSAMdataobj.Rda')
load('input/XSAMsettings.Rda')
load('input/XSAMdatalist.Rda')
load('model/XSAMfit.Rda')
# source('Src/utils.R')
# source('Src/configurationscript.R')

# 
# 
#Load the variance data from survey
# for(file in list.files('bootstrap/data/SamplingVariance/')){
# load(paste('bootstrap/data/SamplingVariance/',file,sep=""))
# }



#Prepare input to retro run
# tmp<-XSAMdataobj$sd_I[,,2]#sd_I_fleet4_1_2_88_17
# # tmp[]<-1
# # tmp[1,]<-sd_I_fleet4NEW_1_2_88_18[1,]
# 
# sdlist<-list(sd_C1_12_88_17[2:12,],
#              sd_I_fleet1NEW_3_12_88_18,
#              tmp,
#              sd_I_fleet5_3_12_88_18)

sdlist <- list(XSAMdataobj$sd_C,XSAMdataobj$sd_I[,,1],XSAMdataobj$sd_I[,,2],XSAMdataobj$sd_I[,,3])


#n<-10
n<-5
XSAMsettings$UseCatchPred<-0
retrofit<-RunXSAMRetro(XSAMdatalist12,XSAMsettings,n=n,constraints=constraints,control=list(iter.max=500,eval.max=500),sdlist=sdlist,StartValFixed=XSAMfit$optobj$par)


save(retrofit,file='model/XSAMretro.Rda')
