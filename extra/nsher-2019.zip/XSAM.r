
#-------------------------------------------------------------------------------#
rm(list=ls())

#Instructions with new assessment: 
#
#       1. Add new line in CForecast, this will include the TAC agreed by the nations


#setwd(dirname(rstudioapi::getSourceEditorContext()$path))


#Load Utils
source('bootstrap/XSAMmodel/constrains.r')
source('bootstrap/utils/utils.r')
source('bootstrap/utils/leaveOut.R')
library(TMB)
library(stockassessment)





#Run standard SAM
cn<-read.ices("bootstrap/init/cn.dat")
cw<-read.ices("bootstrap/init/cw.dat")
dw<-read.ices("bootstrap/init/dw.dat")
lf<-read.ices("bootstrap/init/lf.dat")
lw<-read.ices("bootstrap/init/lw.dat")
mo<-read.ices("bootstrap/init/mo.dat")
nm<-read.ices("bootstrap/init/nm.dat")
pf<-read.ices("bootstrap/init/pf.dat")
pm<-read.ices("bootstrap/init/pm.dat")
sw<-read.ices("bootstrap/init/sw.dat")
surveys<-read.ices("bootstrap/init/Fleet2.csv")
surveys_var<-read.ices("bootstrap/init/Fleet_var.csv")                    #Variance data
# surveys_var<-read.ices("bootstrap/init/Fleet_var_split.csv")
eca_var <-read.csv('bootstrap/init/eca_var.dat',sep=',',stringsAsFactors = F)

#Handling of the eca_variance
eca_var <- eca_var[,2:12]
eca_var<-t(eca_var)
dimnames(eca_var)[[1]]<-NULL
dimnames(eca_var)[[2]]<-NULL
eca_var[is.na(eca_var)]<-1





#-------------------------------------------------------------------------------#
# Grab the Catch prediction
#################################################################################
CForecast<-read.table('bootstrap/init/old_forecasts.csv',skip=3,header=F,sep=";")
names(CForecast)<-c("y","p","a","pp")
CForecast<-rbind(CForecast,c(2015,283013,328740,NA))
CForecast<-rbind(CForecast,c(2016,376612,NA,NA))
CForecast<-rbind(CForecast,c(2017,721566,NA,NA))
CForecast<-rbind(CForecast,c(2018,384197,NA,NA))
CForecast<-rbind(CForecast,c(2019,588562,NA,0.06491057,0.064979))


f0<-lm(log(p)~-1+log(a),data=CForecast)
se<-sqrt(var(f0$res))
rse<-sqrt(exp(se^2)-1)
CatchPrediction<-data.frame(Prediction=CForecast$p,caton=CForecast$a,se=se,rse=rse)
rownames(CatchPrediction)<-CForecast$y

#Do a rescale
CatchPrediction$Prediction<-CatchPrediction$Prediction/1000
save(CatchPrediction,file='input/CatchPrediction.Rda')



#-------------------------------------------------------------------------------#
# Grab settings from model
#################################################################################
XSAMsettings<-ReadXSAMsettings("bootstrap/XSAMmodel/model.txt")
save(XSAMsettings,file = 'input/XSAMsettings.RDa')

XSAMsettings$UseCatchPred<-0


#Rescale as this has been done previousley
surveys$IESNS.bs.her<-surveys$IESNS.bs.her/1000


# asdf
#-------------------------------------------------------------------------------#
# structure the data into a list
#################################################################################
data <- makeXSAMdataobj(rmzeros=TRUE,
                      cn,
                      surveys[c(1,3,2)],
                      fleetIndex=c(0,1,2,3),
                      sampleTime = c(0,0.1666667,0.4166667,0.4166667),
                      mo,sw,cw,nm,pf,pm,XSAMsettings,CatchPrediction,surveys_var = surveys_var[c(1,3,2)],
                      eca_var,corr_RC=NULL,corr_RI=NULL)
save(data,file = 'input/XSAMdata.RDa')

# zxc

#-------------------------------------------------------------------------------#
# Create parameter list
#################################################################################
XSAMpars<-CreateParameterList(data,mapnames=NULL)
save(XSAMpars,file = 'input/XSAMpars.RDa')





compile('bootstrap/XSAMmodel/XSAM.cpp')
dyn.load(dynlib('bootstrap/XSAMmodel/XSAM'))


#load('input/XSAMdataobj.Rda')


# dimnames(data$obs)[[1]]<-dimnames(XSAMdataobj$obs)[[1]]
# 
# dimnames(data$obs)[[1]]<-1:nrow(data$obs)


#Run Fit
#################################################################################

# XSAMfit_old<-FitXSAMFunction(XSAMdataobj,
#                          XSAMpars,
#                          returnObj=T,
#                          constraints=constraints,
#                          control=list(iter.max=500,eval.max=500))

XSAMfit<-FitXSAMFunction(data,
                          XSAMpars,
                          returnObj=T,
                          constraints=constraints,
                          control=list(iter.max=500,eval.max=500))


save(XSAMfit,file='model/XSAMfit.Rda')


plot(XSAMfit$stats$ssb,type='l')
#lines(XSAMfit_old$stats$ssb,col='red')
