#LeaveOut


LO <- function(LOdata){
  
  
  LOfit <- c()
  
  
  XSAMpars<-CreateParameterList(LOdata,mapnames=NULL)
  fit <-FitXSAMFunction(LOdata,
                        XSAMpars,
                        returnObj=T,
                        constraints=constraints,
                        control=list(iter.max=500,eval.max=500))
  
  fit$stats$years <- LOdata$years
  
  LOfit[[1]]<-fit
  
  fleetIDX <- 1:(length(LOdata$fleetIndex)-1)
  for(i in fleetIDX){
    LOdata <- data
    LOdata$SurveyList[[i]]<-NULL
    LOdata$fleetIndex<-LOdata$fleetIndex[!LOdata$fleetIndex==i]
    LOdata$sampleTimes<-LOdata$sampleTimes[-(i+1)]
    LOdata$obs<-LOdata$obs[LOdata$obs[,'fleet']%in%LOdata$fleetIndex,]
    LOdata$nobs<-nrow(LOdata$obs)
    LOdata$agerangeI<-LOdata$agerangeI[-i,]
    LOdata$SurveyIndex<-LOdata$SurveyIndex[-i]
    LOdata$nIndices <-LOdata$nIndices -1
    LOdata$dimI<-LOdata$dimI[-i]
    LOdata$sd_I<-LOdata$sd_I[,,-i]
    LOdata$R_I<-LOdata$R_I[, , , -i]
    
    #Need to fix so it has correct indeks
    LOdata$keyVarObs<-LOdata$keyVarObs[-(i+1),]
    LOdata$keyLogqpar<-LOdata$keyLogqpar[-i,]
    
    nqs<-names(table(LOdata$keyLogqpar))
    LOdata$nqs<-length(nqs[nqs!='-1'])
    
    count = 0
    for(iik in nqs){
      if(iik != '-1'){
        if(iik!=count){
          LOdata$keyLogqpar[LOdata$keyLogqpar==as.integer(iik)]<-as.integer(count)
        }
        count = count+1
      }
    }
    
    count = 0
    for(iik in nqs){
      if(iik != '-1'){
        if(iik!=count){
          LOdata$keyVarObs[LOdata$keyVarObs==as.integer(iik)]<-as.integer(count)
        }
        count = count+1
      }
    }
    
    
    
    
    XSAMpars<-CreateParameterList(LOdata,mapnames=NULL)
    
    
    fit <-FitXSAMFunction(LOdata,
                          XSAMpars,
                          returnObj=T,
                          constraints=constraints,
                          control=list(iter.max=500,eval.max=500))
    
    #add years to fit
    fit$stats$years <- LOdata$years
    LOfit[[i+1]]<-fit
    
  }
  return(LOfit)
}


LOplot <- function(LOfit,plot_type,names){
  library(ggplot2)
  
  #Fix for N
  LOfit[[1]]$stats$N<-LOfit[[1]]$stats$N[1,]
  LOfit[[1]]$stats$Nse<-LOfit[[1]]$stats$Nse[1,]
  
  df <- as.data.frame(LOfit[[1]]$stats[c('years',plot_type,paste0(plot_type,'se'))],grp=1)
  df$grp <- names[1]
  for(i in 2:(length(LOfit))){
    
    #Fix for N
    LOfit[[i]]$stats$N<-LOfit[[i]]$stats$N[1,]
    LOfit[[i]]$stats$Nse<-LOfit[[i]]$stats$Nse[1,]
    
    df1 <- as.data.frame(LOfit[[i]]$stats[c('years',plot_type,paste0(plot_type,'se'))])
    df1$grp<-names[i]
    df<-rbind(df,df1)
  }
  
  ggplot(data=df,aes_string(x='years',y=plot_type,fill='grp'))+
    geom_line(aes_string(group='grp',color='grp'))+   
    theme(legend.position="bottom",legend.title=element_blank())+ 
    guides(col=guide_legend(nrow=2))
  
}