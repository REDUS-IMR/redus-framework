
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

load('model/XSAMfit.Rda')
load('input/XSAMdata.RDa')
load('input/XSAMsettings.RDa')
load('input/XSAMpars.RDa')
source('bootstrap/utils/leaveOut.R')
source('bootstrap/utils/utils.r')
library(TMB)

#Leave Out
# LOfit <- LO(data)
# save(LOfit,file='model/LOfit.Rda')

load('model/LOfit.Rda')
# LOplot(LOfit,'ssb',names=c('base',names(surveys[c(1,3,2)])))
# LOplot(LOfit,'Fbar',names=c('base',names(surveys[c(1,3,2)])))
# LOplot(LOfit,'N',names=c('base',names(surveys[c(1,3,2)])))









#Residal

mybubble2(XSAMfit$res$cstdres,xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)
hist(c(XSAMfit$res$cstdres),breaks = 30)
mybubble2(XSAMfit$res$istdres[[1]],xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)
hist(c(XSAMfit$res$istdres[[1]]),breaks = 30)
mybubble2(XSAMfit$res$istdres[[2]],xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)
hist(c(XSAMfit$res$istdres[[2]]),breaks = 10)
mybubble2(XSAMfit$res$istdres[[3]],xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)
hist(c(XSAMfit$res$istdres[[3]]),breaks = 30)

source('bootstrap/utils/ForecastUtils.R')
# #Denne m� leggest inn
data$SurveyList[[2]]<-data$SurveyList[[2]]/1000
r1<-OneSampleApproach(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars)



mybubble2(r1$cstdres,xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)
mybubble2(r1$istdres[[1]],xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)
mybubble2(r1$istdres[[2]],xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)
mybubble2(r1$istdres[[3]],xlabs=data$years,ylabs=data$minAge:data$maxAge,inches=F)

#Bubbles of weights





#Plot parameters

tmp <- XSAMfit$tab
plot(tmp[,1])

tmp<-as.data.frame(tmp)
tmp$group<-rownames(tmp)
library(ggplot2)


ggplot(tmp, aes(x=group, y=Estimate)) + 
  geom_bar(stat="identity", color="black", 
           position=position_dodge())  + theme(axis.text.x = element_text(angle = 90, hjust = 1))
# +
#   geom_errorbar(aes_string(ymin='Estimate'-'Std. Error', ymax='Estimate'+'Std. Error'), width=.2,
#                 position=position_dodge(.9)) 



library(corrplot)

corr_var <- cov2cor(XSAMfit$rep$cov.fixed)
dimnames(corr_var)[[1]]<-dimnames(XSAMfit$tab)[[1]]
dimnames(corr_var)[[2]]<-dimnames(XSAMfit$tab)[[1]]
  
corrplot(corr_var, method="circle")



mybubble2(cov2cor(XSAMfit$rep$cov.fixed),inches=F,ylab="",xlab="",axes=F)
axis(1,at=1:44,labels=dimnames(XSAMfit$tab)[[1]],las=2,cex.axis=0.7)
axis(2,at=1:44,labels=dimnames(XSAMfit$tab)[[1]],las=2,cex.axis=0.7)
box()



#retro


load('input/CatchPrediction.Rda')
load('input/XSAMdata.RDa')
load('input/XSAMsettings.RDa')
source('bootstrap/XSAMmodel/constrains.r')


library(stockassessment)
surveys<-read.ices(paste0(path,"Fleet2.csv"))
surveys_var<-read.ices(paste0(path,"Fleet_var.csv"))                    #Variance data

#Rescale as this has been done previousley
surveys$IESNS.bs.her<-surveys$IESNS.bs.her/1000


compile('bootstrap/XSAMmodel/XSAM.cpp')
dyn.load(dynlib('bootstrap/XSAMmodel/XSAM'))


retrofit <- retro(n=5,constraints,data,CatchPrediction,XSAMsettings,surveys[c(1,3,2)],surveys_var[c(1,3,2)])
save(retrofit,file='model/retrofit.Rda')


retroplot(retrofit)
retroplot(retrofit,type='Fbar')
retroplot(retrofit,type='R')

