

makeXSAMdataobj <- function(rmzeros=TRUE,cn,surveys=NULL,fleetIndex,sampleTime,mo,sw,cw,nm,pf,pm,XSAMsettings,CatchPrediction,surveys_var,eca_var,corr_RC,corr_RI){
  
  
  
  #Fixing data
  CatchPrediction<-unlist(CatchPrediction[nrow(CatchPrediction),c(1,3)])
  #Add means to the last one in eca var (this has been done previously)
  eca_var<-cbind(eca_var,rowMeans(eca_var))
  
  
  
  dataobj<- c()
  dataobj$caa <- cn
  dataobj$caa[is.na(dataobj$caa)]<--999.000
  dataobj$SurveyList<-c()
  
  
  
  
  for(i in 1:length(surveys)){
    
    if(dim(surveys[[i]])[2]>1){
      
      surveys[[i]]<-surveys[[i]][rowSums(is.na(surveys[[i]])) != ncol(surveys[[i]]), ]
      
    }else{
      
      dimnn <- dimnames(surveys[[i]])[[1]]
      dimnn_age <- dimnames(surveys[[i]])[[2]]
      dimnn<-dimnn[!is.na(surveys[[i]])]
      surveys[[i]]<-surveys[[i]][!is.na(surveys[[i]])]
      surveys[[i]]<-(t(t(surveys[[i]])))    #Must be changed later
      # dimnames(surveys[[i]])[2]<-2            #Must be made more general
      colnames(surveys[[i]])<-2
      rownames(surveys[[i]])<-dimnn
    }
    
    surveys[[i]][is.na(surveys[[i]])]<--999.000
    
    if(rmzeros) surveys[[i]][surveys[[i]]==0]<--999.000
    
    
    
    dataobj$SurveyList[[i]]<-surveys[[i]]
    #Check if lack of age in second survey makes errors in TMB
  }
  
  
  
  dataobj$fleetIndex <- fleetIndex
  dataobj$sampleTimes <- sampleTime
  
  years<- min(as.numeric(rownames(cn))):(max(as.numeric(rownames(cn)))+1)
  
  dataobj$noYears<-length(years)
  dataobj$years <- years
  
  
  
  library(reshape2)
  cn[is.na(cn)]<--999.000
  
  obs <-data.frame(melt(cn,varnames=c('year','age'),value.name = 'obs'),fleet=0)[,c(1,4,2,3)]
  
  for( i in 1:length(surveys)){
    
    
    if(dim(surveys[[i]])[2]>1){
      
      sur <- surveys[[i]]  
      # sur[sur==-999.000]<-NA
      sur<-sur[rowSums(is.na(sur)) != ncol(sur),]
      sur[sur==0]<--999.000
      tmp <- data.frame(melt(sur,varnames=c('year','age'),value.name = 'obs'),fleet=i)[,c(1,4,2,3)]
      obs <-rbind(obs,tmp)
    }else{
      sur <- surveys[[i]]
      # sur[sur==-999.000]<-NA
      age <- dimnames(sur)[[2]]
      namess <- as.numeric(dimnames(sur)[[1]])
      # age<-as.numeric(dimnames(sur)[[2]])
      namess<-namess[!is.na(sur)]
      sur<-sur[!is.na(sur)]
      tt<-t(rbind(as.numeric(namess),as.numeric(i),as.numeric(age),as.numeric(sur)))
      colnames(tt)<-c('year','fleet','age','obs')
      obs <- rbind(obs,data.frame(tt))
    }
  }
  
  #do some tmp stuff to fix to the correct structure  
  obs1 <- obs[,'obs']
  fleet <- obs[,'fleet']
  year <- obs[,'year']
  age <- obs[,'age']
  
  
  
  
  dataobj$obs<- cbind(year,fleet,age,obs1)
  dimnames(dataobj$obs)[[2]]<-c('year','fleet','age','obs')
  dimnames(dataobj$obs)[[1]] <-1:nrow(dataobj$obs)
  
  dataobj$nobs <- nrow(obs)
  dataobj$propMat <- mo
  dataobj$stockMeanWeight<-sw
  dataobj$catchMeanWeight<-cw
  dataobj$natMor<-nm
  dataobj$propF<-pf
  dataobj$propM<-pm
  dataobj$caton  <-rowSums(cw*cn)
  dataobj$minAge <- min(as.integer(colnames(cn)))
  dataobj$maxAge <- max(as.integer(colnames(cn)))
  dataobj$agerangeI <- XSAMsettings$agerangeI
  dataobj$agerangeC <- range(as.integer(colnames(cn)))
  dataobj$UseCatchPred <- XSAMsettings$UseCatchPred
  dataobj$CatchPrediction<-CatchPrediction
  dataobj$maxAgePlusGroup<-XSAMsettings$maxAgePlusGroup
  dataobj$keyLogFconst<-XSAMsettings$keyLogFconst-1     #Sjekk hvorfor det m� trekkes fra 1
  dataobj$keyLogqpar<-XSAMsettings$keyLogqpar-1
  dataobj$keyLogqpar[is.na(dataobj$keyLogqpar)]<--1
  dataobj$Modelq<-XSAMsettings$Modelq
  dataobj$nqs<-length(unique(melt(dataobj$keyLogqpar)$value)[unique(melt(dataobj$keyLogqpar)$value)>=0])
  dataobj$keyVarObs<-XSAMsettings$keyVarObs-1
  dataobj$nObsVar<-length(unique(melt(dataobj$keyVarObs)$value)[unique(melt(dataobj$keyVarObs)$value)>=0])
  dataobj$stockRecruitmentModelCode<-XSAMsettings$stockRecruitmentModelCode
  dataobj$nIndices <- length(surveys)
  dataobj$SurveyIndex <- 1:length(surveys)
  dataobj$dimC <- ncol(cn)
  dataobj$dimI <- c()
  for(i in 1:length(surveys)){
    if(is.null(ncol(surveys[[i]]))){
      dataobj$dimI <- c(dataobj$dimI,1)
    }else{
      dataobj$dimI<-c(dataobj$dimI,ncol(surveys[[i]]))
    }
  }
  
  
  
  dataobj$sd_C<-eca_var  
  
  
  #Add correlation in recruitement
  #for now no correlation
  if(is.null(corr_RC)){
    num_year <- length(as.integer(XSAMsettings$yearrange[1]):as.integer(XSAMsettings$yearrange[2]))
    num_age <- length(as.integer(XSAMsettings$agerange[1]):as.integer(XSAMsettings$agerange[2]))
    corr_RC <- array(numeric(),c(num_age,num_age,num_year) )
    for(aa in 1:num_year){
      corr_RC[,,aa]<-diag(x=1,num_age,num_age)
    }
  }else{print('NO correlation has been implemented for catch')}
  
  dataobj$R_C <- corr_RC
  
  
  
  
  
  
  num_ages <- length((XSAMsettings$agerangeI[,1]):max(XSAMsettings$agerangeI[,2]))
  num_year <- length(as.integer(XSAMsettings$yearrange[1]):as.integer(XSAMsettings$yearrange[2]))
  sd_I <- array(numeric(),c(num_ages,num_year,length(surveys_var)) )
  
  for(i in 1:length(surveys_var)){
    
    #fill in missing years
    tmp<-matrix(1,nrow=num_year,ncol = num_ages)
    colnames(tmp)<-(XSAMsettings$agerangeI[,1]):max(XSAMsettings$agerangeI[,2])
    rownames(tmp)<-as.integer(XSAMsettings$yearrange[1]):as.integer(XSAMsettings$yearrange[2])
    
    
    tmp2 <- surveys_var[[i]]
    tmp2[is.na(tmp2)]<-1
    if(dim(tmp2)[2]==1){
      for( year in rownames(tmp)){
        if(year%in% rownames(tmp2)){
          tmp[year,1]<-sqrt(tmp2[year,])
        }
      }
      
    }else{
      for( year in rownames(tmp)){
        if(year%in% rownames(tmp2)){
          tmp[year,]<-sqrt(tmp2[year,])
        }
      }}
    
    
    
    
    dimnames(tmp)[[2]]<-NULL
    dimnames(tmp)[[1]]<-NULL
    sd_I[,,i]<-t(tmp)
  }
  
  dataobj$sd_I<- sd_I
  
  
  
  
  
  if(is.null(corr_RI)){
    num_year <- length(as.integer(XSAMsettings$yearrange[1]):as.integer(XSAMsettings$yearrange[2]))
    num_age <- (length(as.integer(XSAMsettings$agerange[1]):as.integer(XSAMsettings$agerange[2])))-1    #ADD hock solution
    corr_RI <- array(numeric(),c(num_age,num_age,num_year,length(surveys_var)) )
    for(aa in 1:num_year){
      for(sa in 1:length(surveys_var)){
        corr_RI[,,aa,sa]<-diag(x=1,num_age,num_age)
      }
    }
  }else{print('NO correlation has been implemented for catch')}
  
  dataobj$R_I <- corr_RI
  
  dataobj$NAval <--999
  
  dataobj$Fbarminage<- min(XSAMsettings$Fbarrange)
  dataobj$Fbarmaxage<- max(XSAMsettings$Fbarrange)
  dataobj$CatchConstraint<- (XSAMsettings$CatchConstraint)
  dataobj$keyVarF<- (XSAMsettings$keyVarF)-1
  
  dataobj$nvf <- 1  #Dont know this one!!!
  
  dataobj$corFlaglogF <-XSAMsettings$corFlaglogF
  dataobj$LatentEffort <-XSAMsettings$LatentEffort
  dataobj$TSsel <-XSAMsettings$TSsel
  dataobj$corFlagU <-XSAMsettings$corFlagU
  dataobj$EstimateARInterceptEffort <-XSAMsettings$EstimateARInterceptEffort
  dataobj$EstimateUInterceptEffort <-XSAMsettings$EstimateUInterceptEffort
  dataobj$ymeantype <-XSAMsettings$ymeantype
  dataobj$am <-XSAMsettings$am -1
  dataobj$Am <-XSAMsettings$Am -1
  
  
  dataobj$A <- 11    #Dont know this one!!!!
  
  dataobj$AT <-XSAMsettings$AT -1
  dataobj$RecruitmentProcess <-XSAMsettings$RecruitmentProcess
  
  dataobj$uam <- 9     #dont know this one!!!
  dataobj$ReturnLL <- 0
  
  return(dataobj)
  
}

ReadXSAMsettings<-function(file="",CheckFile=T){
  variables<-c(
    "agerange",
    "yearrange",
    "maxAgePlusGroup",
    "stockRecruitmentModelCode",
    "CatchConstraint",
    "corFlaglogF",
    "LatentEffort",
    "TSsel",
    "corFlagU",
    "EstimateARInterceptEffort",
    "EstimateUInterceptEffort",
    "ymeantype",
    "am",
    "Am",
    "AT",
    "RecruitmentProcess",
    "keyLogFconst",
    "keyVarF",
    "fleetIndex",
    "Modelq",
    "keyLogqpar",
    "keyVarObs",
    "Fbarrange",
    "agerangeC",
    "agerangeI",
    "UseCatchPred"
  )
  tt<-scan(file,what="",sep="\n",comment.char = "#",flush=T,quiet=T)
  #------------------------------------------#
  #Check that required headers are present
  #------------------------------------------#
  fileheaders<-tt[tt%in%variables]
  missingheaders<-variables[!variables%in%fileheaders]
  if(length(missingheaders)>0)stop(paste("Required headers:<",paste(missingheaders,collapse=", "),"> are missing from input file",collapse=" "))
  #------------------------------------------#
  #Check for redundant headers
  #------------------------------------------#
  fileheaders<-lapply(tt,FUN=function(x){x<-strsplit(x,split=" ");x[[1]][[1]][1]})
  fileheaders<-lapply(fileheaders,FUN=function(x){if(x=="NA"){x<--999};x})
  options(warn=-1)
  fileheaders<-unlist(lapply(fileheaders,FUN=function(x)as.numeric(x)))
  options(warn=0)
  fileheaders<-tt[is.na(fileheaders)]
  redunantheaders<-fileheaders[!fileheaders%in%variables]
  if(length(redunantheaders)>0)stop(paste("Headers:<",paste(redunantheaders,collapse=", "),"> found in input file are redundant for XSAM and results in erroneous interpretation of model setup. \nNote that this function does not accept leading blanks for numerical values as they will be interpreted as a header!\nUse leading # to insert comments",collapse=" "))
  #Must sort variables according to ordering in file
  #h0<<-variables
  #h1<<-fileheaders
  #variables<-variables[match(variables,fileheaders)]
  variables<-variables[match(fileheaders,variables)]
  #h2<<-variables
  headerpositions<-match(variables,tt)
  #print(headerpositions)
  #k0<<-tt
  nlines<-diff(c(headerpositions,length(tt)+1))-1
  #print(nlines)
  out<-list()
  for(i in 1:length(variables)){
    #print(variables[i])
    #print(nlines[i])
    out[[i]]<-NULL
    ncols<-c()
    for(k in 1:nlines[i]){
      tmp<-unlist(strsplit(tt[headerpositions[i]+k],split=" "))
      tmp[tmp=="NA"]<-"-9999"
      tmp<-as.numeric(tmp)
      tmp<-tmp[!is.na(tmp)]
      ncols[k]<-length(tmp)
      if(k>1){
        if(ncols[k]!=ncols[k-1])stop(paste("Different number of columns for",variables[i],sep=""))
        out[[i]]<-rbind(out[[i]],tmp)
      }
      else out[[i]]<-tmp
    }
    if(k>1)dimnames(out[[i]])[[1]]<-NULL
    out[[i]][out[[i]]==-9999]<-NA
    names(out)[i]<-variables[i]
  }
  if(is.null(dim(out$keyLogqpar)))out$keyLogqpar<-matrix(out$keyLogqpar,nrow=1)
  if(is.null(dim(out$agerangeI)))out$agerangeI<-matrix(out$agerangeI,nrow=1)
  if(CheckFile)CheckXSAMsettings(out)
  out
}


CheckXSAMsettings<-function(settings){
  n<-0
  #Check correspondance in age ranges
  nages<-diff(settings$agerange)+1
  dimF<-length(settings$keyLogFconst)
  dimq<-dim(settings$keyLogqpar)[2]
  dimvarobs<-dim(settings$keyVarObs)[2]
  if(dimF!=nages){warning("Age span in keyLogFconst is different than age span: May result in crash or erroneous results!");n<-n+1}
  if(dimq!=nages){warning("Age span in keyLogqpar is different than age span: May result in crash or erroneous results!");n<-n+1}
  if(dimvarobs!=nages){warning("Age span in keyVarObs is different than age span: May result in crash or erroneous results!");n<-n+1}
  #
  dimF<-length(settings$keyVarF)
  if(dimF!=nages){warning("Age span in keyVarF is different than age span: May result in crash or erroneous results!");n<-n+1}
  #
  nIndices<-length(settings$fleetIndex)-1
  dimq<-dim(settings$keyLogqpar)[1]
  if(nIndices>dimq){warning("Number of indices is larger than number of q vectors: Will result in crash!");n<-n+1}
  if(nIndices<dimq){warning("Number of indices is smaller than number of q vectors: They should correspond!");n<-n+1}
  dimq<-dim(settings$agerangeI)[1]
  if(nIndices>dimq){warning("Number of indices is larger than corresponding number of age spans provided: Will result in crash!");n<-n+1}	
  if(nIndices<dimq){warning("Number of indices is smaller than corresponding number of age spans provided: They should correspond!");n<-n+1}
  uniqueF<-unique(settings$keyLogFconst)
  #Check consistency in age settings
  minA<-settings$agerange[1]
  maxA<-settings$agerange[2]
  if(settings$Am>maxA){warning("Am must be <=maximum A. Will result in crash!");n<-n+1}
  if(settings$am>settings$Am){warning("am must be <=Am. Will result in crash!");n<-n+1}
  if(settings$AT<maxA){warning("AT must be >=maximum A. Will result in crash!");n<-n+1}
  tmptest<-CheckOrdering(settings$keyLogFconst)
  if(tmptest$error==1){warning("Start value of keyLogFconst should be 0 or 1. Will result in crash!");n<-n+1}
  if(tmptest$error%in%c(2,4)){warning("Ordering of keyLogFconst is not chronological. Is this correct? May cause undesireable results if not deliberately set!");n<-n+1}
  if(tmptest$error==3){warning("Largest value of index is larger than the dimension of keyLogFconst. Will result in crash!");n<-n+1}
  start1<-tmptest$start
  tmptest<-CheckOrdering(settings$keyVarF)
  if(tmptest$error==1){warning("Start value of keyVarF should be 0 or 1. Will result in crash!");n<-n+1}
  if(tmptest$error%in%c(2,4)){warning("Ordering of keyVarF is not chronological. Is this correct? May cause undesireable results if not deliberately set!");n<-n+1}
  if(tmptest$error==3){warning("Largest value of index is larger than the dimension of keyVarF. Will result in crash!");n<-n+1}
  start2<-tmptest$start
  tmptest<-CheckOrdering(t(settings$keyLogqpar))
  if(tmptest$error==1){warning("Start value of keyLogqpar should be 0 or 1. Will result in crash!");n<-n+1}
  if(tmptest$error%in%c(2,4)){warning("Ordering of keyLogqpar is not chronological. Will result in crash!");n<-n+1}
  if(tmptest$error==3){warning("Largest value of index is larger than the dimension of keyLogqpar. Will result in crash!");n<-n+1}
  start3<-tmptest$start
  tmptest<-CheckOrdering(t(settings$keyVarObs))
  if(tmptest$error==1){warning("Start value of keyVarObs should be 0 or 1. Will result in crash!");n<-n+1}
  if(tmptest$error%in%c(2,4)){warning("Ordering of keyVarObs is not chronological. Will result in crash!");n<-n+1}
  if(tmptest$error==3){warning("Largest value of index is larger than the dimension of keyVarObs. Will result in crash!");n<-n+1}
  start4<-tmptest$start
  if(!sum(c(start1,start2,start3,start4))%in%c(0,4)){warning("Start value of indexing of keyLogFconst, keyVarF, keyLogqpar and keyVarObs must be consistent and either 0 or 1. Will result in crash!");n<-n+1}
  #Check correspondance between agerangeI and keyLogqpar
  if(settings$Modelq==0){
    agerangeI<-settings$agerangeI
    #print(agerangeI)
    keyLogqpar<-settings$keyLogqpar
    for(i in 1:nrow(keyLogqpar)){
      idx<-1:length(minA:maxA)
      nonapos<-match(agerangeI[i,1]:agerangeI[i,2],minA:maxA)
      napos<-(1:length(idx))[is.na(match(minA:maxA,agerangeI[i,1]:agerangeI[i,2]))]
      #Check correspondance with keyLogqpar
      keyidx<-keyLogqpar[i,]
      #First test: If keyLogqpar states NA values for q for ages that is included by agerange
      test1<-keyidx[nonapos]
      test1[test1<0]<-NA
      if(sum(!is.na(test1))!=length(nonapos)){warning(paste("keyLogqpar dictates NA for ages contained in agerange for index:",i,"Include the correct index or correct age range!",sep=" "));n<-n+1}
      #Second test: If keyLogqpar  values for q outside ages defined by agerange
      test2<-keyidx[napos]
      test2[test2<0]<-NA
      if(sum(is.na(test2))!=length(napos)){warning(paste("keyLogqpar is specified for ages outside agerange for index:",i,"Include the correct indices or correct age range!",sep=" "));n<-n+1}
    }
  }
  if(n>0){
    warning(paste("'CheckXSAMsettings' found",n,"potential problems with the setting file that may need attention!",collapse=" "))
  }
  else{
    cat("Found the setting file OK!\n")
  }
}


CheckOrdering<-function(vec,rmvals=T){
  #Check whether first value is 0 or 1 and then ordering of vector
  #If rmvals NAs and negative values are removed before checking
  n<-length(vec)
  error<-0
  if(rmvals){
    vec<-vec[!is.na(vec) & vec>=0]
  }
  x0<<-vec
  vec<-unique(vec)
  #Test 1
  if(!vec[1]%in%c(0,1))error<-1
  #Test 2
  if(sum(diff(vec))!=(length(vec)-1))error<-2
  start<-vec[1]
  stopp<-max(vec)#vec[length(vec)]
  #Test 3
  if(stopp>n)error<-3
  #Test4; the unique operation remove bits of vec that may be descending after reached maximum
  if(sum(diff(x0)<0)>0)error<-4
  
  list(error=error,start=start,stopp=stopp)
}


FitXSAMFunction<-function(dataobj,pars,control=list(eval.max=200,iter.max=150),lower=-Inf,upper=Inf,constraints=NULL,includeDiagnostics=T,returnObj=F){
  obj <- MakeADFun(dataobj,pars$ParameterList,random=c("LP"),DLL="XSAM",map=list(FixedPars=factor(pars$MapVector)))
  lower <- obj$par*0+lower
  upper <- obj$par*0+upper
  parnames<-pars$ParameterNames[!is.na(pars$MapVector)]
  print(parnames)
  print(lower)
  if(!is.null(constraints)){
    for(i in 1:length(constraints)){
      lower[parnames==constraints[[i]]$par]<-constraints[[i]]$lower
      upper[parnames==constraints[[i]]$par]<-constraints[[i]]$upper
    }
  }
  system.time(optobj<-nlminb(obj$par,obj$fn,obj$gr,control=control,lower=lower,upper=upper))
  #cbind(optXSAMobj$par,XSAMpars$ParameterNames[!is.na(XSAMpars$MapVector)])
  if(optobj$convergence==0){
    if(returnObj)rep<-sdreport(obj,getJointPrecision=T)
    else rep<-sdreport(obj)
    tab<-CreateReportTable(rep,pars)
    stats<-extractStatsG(report=summary(rep,"report"),dataobj=dataobj)
    if(includeDiagnostics)res<-ExtractResiduals(stats,tab,dataobj)
    else res<-NULL
  }
  else{
    rep<-tab<-stats<-res<-NULL
  }
  if(returnObj)obj<-obj
  else obj<-NULL
  convergence<-optobj$convergence
  list(convergence=convergence,optobj=optobj,rep=rep,tab=tab,stats=stats,res=res,obj=obj)
}


CreateReportTable<-function(repobj,parobj){
  stab<-summary(repobj,"fixed")
  dimnames(stab)[[1]]<-names(parobj$ParameterList$FixedPars)[!is.na(parobj$MapVector)]
  stab
}


extractStatsG<-function(report,dataobj){
  
  tmp<-report[dimnames(report)[[1]]%in%"N",1]
  N<-matrix(tmp,nrow=dataobj$AT,ncol=dataobj$noYears)
  tmp<-report[dimnames(report)[[1]]%in%"N",2]
  Nse<-matrix(tmp,nrow=dataobj$AT,ncol=dataobj$noYears)
  
  tmp<-report[dimnames(report)[[1]]%in%"logN",1]
  logN<-matrix(tmp,nrow=dataobj$AT,ncol=dataobj$noYears)
  tmp<-report[dimnames(report)[[1]]%in%"logN",2]
  logNse<-matrix(tmp,nrow=dataobj$AT,ncol=dataobj$noYears)
  
  tmp<-report[dimnames(report)[[1]]%in%"F",1]
  FF<-matrix(tmp,nrow=dataobj$A,ncol=dataobj$noYears)
  tmp<-report[dimnames(report)[[1]]%in%"F",2]
  FFse<-matrix(tmp,nrow=dataobj$A,ncol=dataobj$noYears)
  
  tmp<-report[dimnames(report)[[1]]%in%"logF",1]
  logF<-matrix(tmp,nrow=dataobj$Am,ncol=dataobj$noYears)
  tmp<-report[dimnames(report)[[1]]%in%"logF",2]
  logFse<-matrix(tmp,nrow=dataobj$Am,ncol=dataobj$noYears)
  
  if(dataobj$Am<dataobj$A){
    for(a in dataobj$Am:dataobj$A){
      logF<-rbind(logF,logF[dataobj$Am,])
      logFse<-rbind(logFse,logFse[dataobj$Am,])
    }
  }
  
  
  Fbar<-report[dimnames(report)[[1]]%in%"Fbar",1]
  Fbarse<-report[dimnames(report)[[1]]%in%"Fbar",2]
  
  FbarW<-report[dimnames(report)[[1]]%in%"FbarW",1]
  FbarWse<-report[dimnames(report)[[1]]%in%"FbarW",2]
  
  ssb<-report[dimnames(report)[[1]]%in%"ssb",1]
  ssbse<-report[dimnames(report)[[1]]%in%"ssb",2]
  
  totb<-report[dimnames(report)[[1]]%in%"totb",1]
  totbse<-report[dimnames(report)[[1]]%in%"totb",2]
  
  list(N=N,Nse=Nse,FF=FF,FFse=FFse,Fbar=Fbar,Fbarse=Fbarse,FbarW=FbarW,FbarWse=FbarWse,ssb=ssb,ssbse=ssbse,totb=totb,totbse=totbse,logN=logN,logNse=logNse,logF=logF,logFse=logFse)
}


PC<-function(fitobj,dataobj){
  N<-fitobj$N
  #print(N)
  FF<-fitobj$FF
  #print(FF)
  A<-dataobj$A
  Y<-dataobj$noYears
  M<-t(dataobj$natMor)
  am<-max(dataobj$keyLogFconst)+1
  if(am<A){
    for(a in (am+1):A){
      FF<-rbind(FF,FF[am,])
    }
  }
  #print(c(A,Y,am))
  caa<-matrix(NA,nrow=A,ncol=Y)
  years<-dataobj$years
  datayears<-as.numeric(dimnames(dataobj$caa)[[1]])
  pcaa<-matrix(NA,nrow=A,ncol=Y)
  for(y in 1:Y){
    pcaa[1:A,y]<-FF[1:A,y]/(FF[1:A,y]+M[1:A,y])*(1-exp(-(FF[1:A,y]+M[1:A,y])))*N[1:A,y]
  }
  caa[,match(datayears,years)]<-t(dataobj$caa)
  
  list(pcaa=pcaa,caa=caa)
}


PI<-function(fitobj,partab,dataobj,indeks=1){
  N<-fitobj$N
  FF<-fitobj$FF
  A<-dataobj$A
  Y<-dataobj$noYears
  M<-t(dataobj$natMor)
  am<-max(dataobj$keyLogFconst)+1
  if(am<A){
    for(a in (am+1):A){
      FF<-rbind(FF,FF[am,])
    }
  }
  
  #Get the correct qs
  agerange<-dataobj$agerangeI[indeks,]
  ages<-agerange[1]:agerange[2]
  ageindeks<-ages-dataobj$minAge+1
  #print(ageindeks)
  qpos<-grep("logqpar",dimnames(partab)[[1]])
  qs<-partab[qpos,1]
  agepos<-dataobj$keyLogqpar[indeks,]+1
  #print(agepos)
  #ageindeks<-ageindeks[agepos>0]
  #print(ageindeks)
  agepos<-agepos[agepos>0]
  logqs<-qs[agepos]
  print(logqs)
  deltaY<-dataobj$sampleTimes[indeks+1]
  piaa<-matrix(NA,nrow=A,ncol=Y)
  iaa<-matrix(NA,nrow=A,ncol=Y)
  niaa<-matrix(NA,nrow=A,ncol=Y)
  years<-dataobj$years
  datayears<-as.numeric(dimnames(dataobj$SurveyList[[indeks]])[[1]])
  for(y in 1:length(years)){
    piaa[ageindeks,y]<-exp(logqs)*N[ageindeks,y]*exp(-(FF[ageindeks,y]+M[ageindeks,y])*deltaY)
  }
  iaa[ageindeks,match(datayears,years)]<-t(dataobj$SurveyList[[indeks]])
  iaa[iaa==-999]<-NA
  for(y in 1:length(years)){
    niaa[ageindeks,y]<-iaa[ageindeks,y]/exp(logqs)*exp(+(FF[ageindeks,y]+M[ageindeks,y])*deltaY)
  }
  
  list(piaa=piaa,iaa=iaa,niaa=niaa)
}


ExtractResiduals<-function(reslist,partab,dataobj){
  cres<-PC(reslist,dataobj)
  co<-log(cres$caa)
  cp<-log(cres$pcaa)
  logcaa<-log(cres$caa)
  cres<-(log(cres$caa)-log(cres$pcaa))
  varmatC<-matrix(NA,nrow=dataobj$dimC,ncol=dataobj$noYears)
  if(sum(dimnames(partab)[[1]]=="loghvec1")==1){
    h<-exp(partab[dimnames(partab)[[1]]=="loghvec1",1])
  }
  else{
    if(sum(dimnames(partab)[[1]]=="loghvec")==1){
      h<-exp(partab[dimnames(partab)[[1]]=="loghvec",1])[1]
    }
    else h<-1
  }
  for(i in 1:dataobj$noYears)varmatC[,i]<-h*dataobj$sd_C[,i]^2
  varmatC[is.na(co)]<-NA
  wmatC<-1/varmatC
  cvC<-sqrt(exp(varmatC)-1)
  cstdres<-cres/sqrt(varmatC)
  logiaa<-ires<-istdres<-cvI<-logniaa<-list()
  loghnames<-grep("loghvec",dimnames(partab)[[1]])
  loghnames<-dimnames(partab)[[1]][loghnames]
  print(loghnames)
  
  #varmatI<-wmatI<-array(NA,c(dataobj$A,dataobj$noYears,dataobj$nIndices))
  #varmatI<-wmatI<-array(NA,c(max(dataobj$dimI),dataobj$noYears,dataobj$nIndices))
  varmatI<-wmatI<-array(NA,c(dataobj$A,dataobj$noYears,dataobj$nIndices))
  io<-ip<-list()
  for(i in 1:dataobj$nIndices){
    agerange<-dataobj$agerangeI[i,]
    ages<-agerange[1]:agerange[2]
    ageindeks<-ages-dataobj$minAge+1
    print(ageindeks)
    ires[[i]]<-PI(fitobj=reslist,partab=partab,dataobj=dataobj,indeks=i)
    io[[i]]<-log(ires[[i]]$iaa)
    ip[[i]]<-log(ires[[i]]$piaa)
    logiaa[[i]]<-log(ires[[i]]$iaa)
    logniaa[[i]]<-log(ires[[i]]$niaa)
    ires[[i]]<-(log(ires[[i]]$iaa)-log(ires[[i]]$piaa))
    #varmat<-matrix(NA,nrow=dataobj$dimI[1],ncol=dataobj$noYears)
    #varmat<-matrix(NA,nrow=dataobj$dimI[i],ncol=dataobj$noYears)
    #varmat<-matrix(NA,nrow=max(dataobj$A),ncol=dataobj$noYears)
    if(length(loghnames)>0){
      if(length(loghnames)<(i+1))loghnames[i+1]<-loghnames[i]
      if(sum(dimnames(partab)[[1]]==loghnames[i+1])==1){
        h<-exp(partab[dimnames(partab)[[1]]==loghnames[i+1],1])
      }
      else h<-exp(partab[dimnames(partab)[[1]]=="loghvec",1])[i+1]
    }
    else{
      h<-1
    }
    #for(y in 1:dataobj$noYears)varmat[,y]<-h*dataobj$sd_I[,y,i]^2
    #for(y in 1:dataobj$noYears)varmat[1:dataobj$dimI[i],y]<-h*dataobj$sd_I[1:dataobj$dimI[i],y,i]^2
    for(y in 1:dataobj$noYears){
      print(y)
      #print(varmatI[1:dataobj$dimI[i],y,i])
      #print(dataobj$sd_I[1:dataobj$dimI[i],y,i])
      #varmatI[1:dataobj$dimI[i],y,i]<-h*dataobj$sd_I[1:dataobj$dimI[i],y,i]^2
      print(dataobj$sd_I[,y,i])
      #varmatI[ageindeks,y,i]<-h*dataobj$sd_I[ageindeks,y,i]^2
      varmatI[ageindeks,y,i]<-h*dataobj$sd_I[1:length(ageindeks),y,i]^2
      print(varmatI[,y,i])
      print(io[[i]][,y])
      #varmatI[1:dataobj$dimI[i],y,i][is.na(io[[i]][,y])]<-NA
      #varmatI[1:dataobj$dimI[i],y,i][is.na(io[[i]][dataobj$agerangeI[i,1]:dataobj$agerangeI[i,2],y])]<-NA
      varmatI[ageindeks,y,i][is.na(io[[i]][ageindeks,y])]<-NA
    }
    wmatI[,,i]<-1/varmatI[,,i]
    #cvI[[i]]<-sqrt(exp(varmat)-1)
    cvI[[i]]<-sqrt(exp(varmatI[,,i])-1)
    print("i");print(i)
    print(ires[[i]]);print(varmatI[,,i])
    #istdres[[i]]<-ires[[i]]/sqrt(varmat)
    #istdres[[i]]<-ires[[i]]/sqrt(varmatI[,,i])
    print("blarh")
    #print(ires[[i]][dataobj$agerangeI[i,1]:dataobj$agerangeI[i,2],])
    print(ires[[i]][ageindeks,])
    print("blarh2")
    print(dim(varmatI));print(dataobj$dimI[i])
    #print(varmatI[1:dataobj$dimI[i],,i])
    print(varmatI[ageindeks,,i])
    #istdres[[i]]<-ires[[i]][dataobj$agerangeI[i,1]:dataobj$agerangeI[i,2],]/sqrt(varmatI[1:dataobj$dimI[i],,i])
    #istdres[[i]]<-ires[[i]][ageindeks,]/sqrt(varmatI[ageindeks,,i])
    istdres[[i]]<-ires[[i]]/sqrt(varmatI[,,i])
    print(istdres[[i]])
  }
  list(cres=cres,cstdres=cstdres,cvC=cvC,logcaa=logcaa,ires=ires,istdres=istdres,cvI=cvI,logiaa=logiaa,logniaa=logniaa,varmatC=varmatC,varmatI=varmatI,co=co,cp=cp,io=io,ip=ip,wmatC=wmatC,wmatI=wmatI)
}


mapvec<-function(vec,fixname=NULL){
  map<-1:length(vec)
  if(!is.null(fixname)){
    map[names(vec)%in%fixname]<-NA
    #Reorder
    map[!is.na(map)]<-1:length(map[!is.na(map)])
  }	
  map	
}


CreateParameterList<-function(dataobj,mapnames=NULL,sv=0){
  #-----------------------------------------------#
  #First determine dimension of latent variables
  #-----------------------------------------------#
  dimL<-dataobj$Am
  if(dataobj$TSsel==1)dimL<-dimL+(dataobj$am-1)
  if(dataobj$LatentEffort==1)dimL<-dimL+1
  dimL<-dimL+1#For Y
  if(dataobj$RecruitmentProcess==1)dimL<-dimL+1
  #-----------------------------------------------#
  #Then set up parameterlist
  #-----------------------------------------------#
  parameterlist<-list(
    initlogN=rep(0,dataobj$A-1),
    R=if(dataobj$RecruitmentProcess==0){rep(numeric(1),dataobj$noYears)}else{numeric(0)},
    logqpar=if(dataobj$Modelq==1){rep(-10,3*dataobj$nIndices)}else{rep(0,max(dataobj$keyLogqpar)+1)},
    #logs2_1=0,
    logs2_1=rep(0,max(dataobj$keyVarF)+1),
    logs2_2=if(dataobj$TSsel==1){numeric(1)}else{numeric(0)},
    logs2_3=if(dataobj$LatentEffort==1){numeric(1)}else{numeric(0)},
    logs2_4=0,
    logsR2=if(dataobj$RecruitmentProcess==1){numeric(1)}else{numeric(0)},
    loghvec=rep(0,max(dataobj$keyVarObs)+1),
    rec_loga=0,
    rec_logb=0,
    rhoU=if(dataobj$TSsel==1 & dataobj$corFlagU>0){numeric(1)}else{numeric(0)}, 
    rhologF=if(dataobj$corFlaglogF>0){numeric(1)}else{numeric(0)}, 
    aYpar=if(dataobj$EstimateARInterceptEffort==1){numeric(1)}else{numeric(0)},
    bY=1,
    Upar=if(dataobj$TSsel==0){rep(numeric(1),dataobj$am-1)}else{numeric(0)},
    aUpar=if(dataobj$TSsel==1 & dataobj$EstimateUInterceptEffort==1){rep(numeric(1),dataobj$uam)}else{numeric(0)},
    bU=if(dataobj$TSsel==1){1}else{numeric(0)}#,
    #PredictCatchPars=dataobj$PredictCatchPars
  )
  #Convert to vector
  ParameterVector<-unlist(parameterlist)
  ParameterNames<-names(ParameterVector)
  #Identify parameters to map
  if(dataobj$RecruitmentProcess){
    if(dataobj$stockRecruitmentModelCode%in%0:1)mapnames<-c(mapnames,"rec_loga","rec_logb")
    if(dataobj$stockRecruitmentModelCode==5)mapnames<-c(mapnames,"rec_logb")
  }
  else mapnames<-c(mapnames,"rec_loga","rec_logb")
  #if(dataobj$PredictCatchPars[1]>0)mapnames<-c(mapnames,c("PredictCatchPars1","PredictCatchPars2"))
  #mapnames<-c(mapnames,c("PredictCatchPars1","PredictCatchPars2"))
  cat("Parameters mapped (also due to specified stock-recruitment model):\n")
  print(mapnames)
  #vector of names to map
  MapVector<-mapvec(ParameterVector,mapnames)
  #Parameterlist
  ParameterList <- list(
    FixedPars=ParameterVector,
    LP=matrix(sv, nrow=dimL ,ncol=dataobj$noYears)
  )
  list(ParameterList=ParameterList,MapVector=MapVector,ParameterNames=ParameterNames)
}


mybubble2<-function(res,inches=.25,xlabs=NULL,ylabs=NULL,addScale=T,xtxt=c(-3,-1,0.5),ytxt=1,axes=T){
  ylim<-range(row(res))+c(-1,1)
  xlim<-range(col(res))+c(-1,1)
  
  if(axes)plot(0,0,xlim=xlim,ylim=ylim,type="n",xlab="Year",ylab="Age",axes=F)
  else plot(0,0,xlim=xlim,ylim=ylim,type="n",xlab="",ylab="",axes=F)
  
  if(axes){
    if(is.null(xlabs))axis(1)
    else axis(1,at=(xlim[1]+1):(xlim[2]-1),labels=xlabs)
  }
  if(axes){
    if(is.null(ylabs))axis(2)
    else axis(2,at=(ylim[1]+1):(ylim[2]-1),labels=ylabs)
  }
  
  if(axes)box()
  
  colv<-c("blue","red")
  colv<-c("red","blue")
  colm<-res
  colm<-colv[1]
  colm[res<0]<-colv[2]
  colm[res>=0]<-colv[1]
  
  tmp<-res
  tmp<-abs(res)
  radius <- sqrt( tmp/ pi )
  print(radius)
  symbols(col(tmp), row(tmp), circles=c(radius),fg="white",bg=c(colm),add=T,inches=inches)
  
  if(addScale){
    rr <- sqrt( 1/ pi )
    #text(xlim[2]-3,ylim[2]+1,"Scale:",xpd=T)
    #symbols(xlim[2]-1, ylim[2]+1, circles=rr,fg="white",bg=colv[1],add=T,inches=F,xpd=NA)
    #text(xlim[2]+.5,ylim[2]+1,"=+1",xpd=T)
    text(xlim[2]+xtxt[1],ylim[2]+ytxt,"Scale:",xpd=T)
    symbols(xlim[2]+xtxt[2], ylim[2]+ytxt, circles=rr,fg="white",bg=colv[1],add=T,inches=F,xpd=NA)
    text(xlim[2]+xtxt[3],ylim[2]+ytxt,"=+1",xpd=T)
  }
}


retro<-function(n=5,constraints,data,CatchPrediction,XSAMsettings,surveys,surveys_var){
  
  source('bootstrap/utils/utils.r')
  library(TMB)
  fit<-c()
  
  
  
  #Run standard SAM
  cn<-data$caa#read.ices(paste0(path,"cn.dat"))
  cw<-data$catchMeanWeight#read.ices(paste0(path,"cw.dat"))
  dw<-data$catchMeanWeight#read.ices(paste0(path,"dw.dat"))
  mo<-data$propMat#read.ices(paste0(path,"mo.dat"))
  nm<-data$natMor#read.ices(paste0(path,"nm.dat"))
  pf<-data$propF#read.ices(paste0(path,"pf.dat"))
  pm<-data$propM#read.ices(paste0(path,"pm.dat"))
  sw<-data$stockMeanWeight#read.ices(paste0(path,"sw.dat"))
  
  eca_var <-data$sd_C[,1:(ncol(data$sd_C)-1)]#read.csv(paste0(path,"eca_var.dat"),sep=',',stringsAsFactors = F)
  # eca_var<-eca_var[2:12]
  dimnames(eca_var)<-dimnames(cn)[c(2,1)]
  
  years <- data$years
  
  for(i in 0:n){
    if(i>0){
      
      years<-years[-length(years)]
      assessment_year <- years[length(years)]
      cn<-cn[as.numeric(dimnames(cn)[[1]])%in%years[-length(years)],]
      # cn[as.character(assessment_year),]<--999
      mo<-mo[as.numeric(dimnames(mo)[[1]])%in%years,]
      sw<-sw[as.numeric(dimnames(sw)[[1]])%in%years,]
      cw<-cw[as.numeric(dimnames(cw)[[1]])%in%years[-length(years)],]
      nm<-nm[as.numeric(dimnames(nm)[[1]])%in%years,]
      pf<-pf[as.numeric(dimnames(pf)[[1]])%in%years,]
      pm<-pm[as.numeric(dimnames(pm)[[1]])%in%years,]
      
      
      print(surveys)
      
      surveys[[1]]<-surveys[[1]][dimnames(surveys[[1]])[[1]]%in%years,]
      dimnn<-dimnames(surveys[[2]])[[2]]
      surveys[[2]]<-t(t(surveys[[2]][dimnames(surveys[[2]])[[1]]%in%years,]))
      print(dimnn)
      dimnames(surveys[[2]])[[2]]<-dimnn
      surveys[[3]]<-((surveys[[3]][dimnames(surveys[[3]])[[1]]%in%years,]))

      surveys_var[[1]]<-surveys_var[[1]][dimnames(surveys_var[[1]])[[1]]%in%years,]
      surveys_var[[2]]<-t(t(surveys_var[[2]][dimnames(surveys_var[[2]])[[1]]%in%years,]))
      dimnames(surveys_var[[2]])[[2]]<-dimnn
      surveys_var[[3]]<-((surveys_var[[3]][dimnames(surveys_var[[3]])[[1]]%in%years,]))
      
      eca_var<-eca_var[,as.numeric(dimnames(eca_var)[[2]])%in%years[-length(years)]]
      XSAMsettings$yearrange[2]<-XSAMsettings$yearrange[2]-1
      
    }
    
    
    
    data <- makeXSAMdataobj(rmzeros=TRUE,
                            cn,
                            surveys,
                            fleetIndex=c(0,1,2,3),
                            sampleTime = c(0,0.1666667,0.4166667,0.4166667),
                            mo,sw,cw,nm,pf,pm,XSAMsettings,CatchPrediction,surveys_var = surveys_var,
                            eca_var,corr_RC=NULL,corr_RI=NULL)
    
    
    XSAMpars<-CreateParameterList(data,mapnames=NULL)
    
    fit[[i+1]]<-FitXSAMFunction(data,
                                XSAMpars,
                                returnObj=T,
                                constraints=constraints,
                                control=list(iter.max=500,eval.max=500))
    fit[[i+1]]$years <- years
    
  }
  fit
  
}


retroplot<-function(retrofit,type='ssb'){
  
  library(ggplot2)
  library(icesAdvice)
  
  if(type=='ssb'){
    
    mohn_struct<-t(as.numeric(retrofit[[1]]$stats$ssb))
    colnames(mohn_struct)<-retrofit[[1]]$years
    rownames(mohn_struct)<-'base'
    for(i in 2:length(retrofit)){
      newline <- c(as.numeric(retrofit[[i]]$stats$ssb),rep(NA,length(retrofit[[1]]$stats$ssb)-length(retrofit[[i]]$stats$ssb)))
      mohn_struct<-rbind(mohn_struct,newline)
      rownames(mohn_struct)[i]<-paste0('-',i-1)
    }
    
    mon<-mohn(t(mohn_struct), peels=length(retrofit)-1)
    
    
    df<-as.data.frame(cbind('years'=retrofit[[1]]$years,'ssb'=as.numeric(retrofit[[1]]$stats$ssb),'ssb_se'=as.numeric(retrofit[[1]]$stats$ssbse)))
    df$colour<-paste0('LO ',0,' year')
    p<-ggplot(data=df,aes(x=years,y=ssb,colour=colour))+geom_line()
    for(i in 2:length(retrofit)){
      df<-as.data.frame(cbind('years'=retrofit[[i]]$years,'ssb'=as.numeric(retrofit[[i]]$stats$ssb),'ssb_se'=as.numeric(retrofit[[i]]$stats$ssbse)))
      df$colour<-paste0('LO ',i-1,' year')
      p<-p+geom_line(data=df,aes(x=years,y=ssb,colour=colour))
    }
    p<-p+ggtitle(paste0('Mohn\'s rho: ', round(mon,digits = 3)))
  }
  if(type=='Fbar'){
    
    mohn_struct<-t(as.numeric(retrofit[[1]]$stats$Fbar))
    colnames(mohn_struct)<-retrofit[[1]]$years
    rownames(mohn_struct)<-'base'
    for(i in 2:length(retrofit)){
      newline <- c(as.numeric(retrofit[[i]]$stats$Fbar),rep(NA,length(retrofit[[1]]$stats$Fbar)-length(retrofit[[i]]$stats$Fbarse)))
      mohn_struct<-rbind(mohn_struct,newline)
      rownames(mohn_struct)[i]<-paste0('-',i-1)
    }
    
    mon<-mohn(t(mohn_struct), peels=length(retrofit)-1)
    
    
    df<-as.data.frame(cbind('years'=retrofit[[1]]$years,'Fbar'=as.numeric(retrofit[[1]]$stats$Fbar),'ssb_se'=as.numeric(retrofit[[1]]$stats$Fbarse)))
    df$colour<-paste0('LO ',0,' year')
    p<-ggplot(data=df,aes(x=years,y=Fbar,colour=colour))+geom_line()
    for(i in 2:length(retrofit)){
      df<-as.data.frame(cbind('years'=retrofit[[i]]$years,'Fbar'=as.numeric(retrofit[[i]]$stats$Fbar),'ssb_se'=as.numeric(retrofit[[i]]$stats$Fbarse)))
      df$colour<-paste0('LO ',i-1,' year')
      p<-p+geom_line(data=df,aes(x=years,y=Fbar,colour=colour))
    }
    p<-p+ggtitle(paste0('Mohn\'s rho: ', round(mon,digits = 3)))
  }
  if(type=='R'){
    
    mohn_struct<-t(as.numeric(retrofit[[1]]$stats$N[1,]))
    colnames(mohn_struct)<-retrofit[[1]]$years
    rownames(mohn_struct)<-'base'
    for(i in 2:length(retrofit)){
      newline <- c(as.numeric(retrofit[[i]]$stats$N[1,]),rep(NA,length(retrofit[[1]]$stats$N[1,])-length(retrofit[[i]]$stats$Nse[1,])))
      mohn_struct<-rbind(mohn_struct,newline)
      rownames(mohn_struct)[i]<-paste0('-',i-1)
    }
    
    mon<-mohn(t(mohn_struct), peels=length(retrofit)-1)
    
    
    df<-as.data.frame(cbind('years'=retrofit[[1]]$years,'R'=as.numeric(retrofit[[1]]$stats$N[1,]),'ssb_se'=as.numeric(retrofit[[1]]$stats$Nse[1,])))
    df$colour<-paste0('LO ',0,' year')
    p<-ggplot(data=df,aes(x=years,y=R,colour=colour))+geom_line()
    for(i in 2:length(retrofit)){
      df<-as.data.frame(cbind('years'=retrofit[[i]]$years,'R'=as.numeric(retrofit[[i]]$stats$N[1,]),'ssb_se'=as.numeric(retrofit[[i]]$stats$Nse[1,])))
      df$colour<-paste0('LO ',i-1,' year')
      p<-p+geom_line(data=df,aes(x=years,y=R,colour=colour))
    }
    p<-p+ggtitle(paste0('Mohn\'s rho: ', round(mon,digits = 3)))
  }
  p
}


DoXSAMSim<-function(dataobj,
                    fitobj,
                    parobj,
                    StochasticForcast=T,
                    Bpars=NULL,
                    Fbarrange=NULL,
                    np=2,n=1000,
                    ManagementPlanPars,
                    BparsType=1,
                    weightedF=F){
  
  if(is.null(Bpars))Bpars<-SetBpars(dataobj,n=np,type=BparsType)
  #1) Deterministic projection using management plan
  FC0<-ProjectPoP(dataobj,fitobj$rep,parobj,Bpars,Fbarrange=Fbarrange,n=np,TACs=NULL,Ftargets=NULL,DeterministicProjection=T,ConstraintType=1,UseManagementPlan=T,ManagementPlanPars=ManagementPlanPars,weightedF=weightedF)
  #2) Deterministic projection using TAC derived from management plan
  FC1<-ProjectPoP(dataobj,fitobj$rep,parobj,Bpars,Fbarrange=Fbarrange,n=np,TACs=FC0$Ctot,Ftargets=NULL,DeterministicProjection=T,ConstraintType=1,UseManagementPlan=F,ManagementPlanPars=ManagementPlanPars,weightedF=weightedF)
  
  #3) Stochastic projection using TAC derived from MP
  TACs<-FC1$Ctot
  if(StochasticForcast){
    #Generate samples from simultaneous distribution of all fitted parameters including latent parameters
    parrepl<-GenerateSimDist(fitobj$rep,dataobj,parobj,n=n)
    tmprepobj<-list()
    FCrepl<-list()
    for(i in 1:nrow(parrepl[[1]])){
      tmprepobj$par.fixed<-parrepl$par.fixed[i,]
      tmprepobj$par.random<-parrepl$par.random[i,]
      #FCrepl[[i]]<-ProjectPoP(dataobj,tmprepobj,parobj=parobj,Bpars,Fbarrange=NULL,n=np,TACs=TACs,Ftargets=NULL,DeterministicProjection=F,ConstraintType=1,weightedF=weightedF)
      FCrepl[[i]]<-SimPoP(dataobj,tmprepobj,parobj=parobj,Bpars,Fbarrange=NULL,n=np,TACs=TACs,Ftargets=NULL,DeterministicProjection=F,UseManagementPlan=F,ConstraintType=3,weightedF=weightedF)
    }
  }
  else{
    FCrepl<-NULL
  }
  years<-FC0$years[1:length(FC0$years)]
  yearsF<-years[1:(length(years)-1)]
  list(FC0=FC0,FC1=FC1,FCrepl=FCrepl,TACs=TACs,years=years,yearsF=yearsF,type=ManagementPlanPars$type,Bpars=Bpars)
}
OneSampleApproach<-function(dataobj,fitobj,parobj){
  ManagementPlanPars<-list()
  ManagementPlanPars$Fs<-NULL
  ManagementPlanPars$Bmp<-5000
  ManagementPlanPars$Fmp<-0.125
  ManagementPlanPars$Fmin<-0.05
  ManagementPlanPars$Btrigger<-5000
  ManagementPlanPars$Blim<-2500
  ManagementPlanPars$Bpa<-NULL
  ManagementPlanPars$Fmsy<-0.15
  ManagementPlanPars$Flim<-NULL
  ManagementPlanPars$Fpa<-0.15
  ManagementPlanPars$type<-"MP"
  
  n<-2
  np<-1
  XSAMsim<-DoXSAMSim(dataobj=dataobj,fitobj=fitobj,parobj=parobj,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T)
  
  k<-1
  
  x<-log(t(dataobj$caa))
  x<-cbind(x,NA)
  cres<-x-log(XSAMsim$FCrepl[[k]]$caa[1:nrow(x),1:ncol(x)])
  #vmat<-XSAMf145TSU$res$varmatC
  vmat<-fitobj$res$varmatC
  cstdres<-cres/sqrt(vmat)
  
  ires<-istdres<-list()
  for(j in 1:dataobj$nIndices){
    x<-matrix(NA,nrow=length(dataobj$minAge:dataobj$maxAge),ncol=length(dataobj$years))
    ags<-dataobj$agerangeI[j,1]:dataobj$agerangeI[j,2]
    agsidx<-(ags-dataobj$minAge+1)
    ys<-as.numeric(dimnames(dataobj$SurveyList[[j]])[[1]])
    yidx<-(ys-min(dataobj$years)+1)
    x[agsidx,yidx]<-(t(dataobj$SurveyList[[j]]))
    y<-log(XSAMsim$FCrepl[[k]]$surveyobslist[[j]][1:nrow(x),1:ncol(x)])
    x[x<0]<-NA
    x<-log(x)
    ires[[j]]<-x-y
    vmat<-fitobj$res$varmatI[,,j]
    istdres[[j]]<-ires[[j]]/sqrt(vmat)
  }
  list(cres=cres,cstdres=cstdres,ires=ires,istdres=istdres)
}

