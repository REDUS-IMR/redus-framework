



#-------------------------------------------------------------------------------#
# Remove everything from memory to avoide conflicts
#-------------------------------------------------------------------------------#
rm(list=ls())



####To do
# Oppdater maturity ogive XSAMdataobj$propMat om n\F8dvendig
#
# Sjekk om en m\E5 kj\F8re fit p\E5 nytt
#
# Oppdater forventet fangst, m\E5 en kj\F8re fitp\E5 nytt??? eller endre det her?
#  
#
# 




#-------------------------------------------------------------------------------#
# Set the working directory to location of the script. 
# (it requieres rstudio)
#-------------------------------------------------------------------------------#
# setwd(dirname(rstudioapi::getSourceEditorContext()$path))






#########################################################
#Require having run "FinalAssessment.R"
#Restore the assessment results
load('model/XSAMfit.Rda')
load('input/XSAMdata.RDa')
load('input/XSAMpars.RDa')
# load('model/XSAMprofileListF.Rda')
# load('input/XSAMdataobj.Rda')
# load('input/XSAMpars.Rda')




#Check this number!!! should be prediction for 2019
# XSAMdataobj$CatchPrediction<-780.0
# XSAMdataobj$CatchPrediction[1]<-546.448
# XSAMdataobj$CatchPrediction[1]<-773.750
# print(XSAMdataobj$CatchPrediction)


data$CatchPrediction[1]<-773.750
print(data$CatchPrediction)

#THis is the last TAC
TAC <- 588562


XSAMfit$tab['rec_loga',]
XSAMfit$tab['logsR2',]






################################################################
#FORECASTING
################################################################

ManagementPlanPars<-list()
ManagementPlanPars$Fs<-NULL
ManagementPlanPars$Bmp<-3184
ManagementPlanPars$Fmp<-0.14
ManagementPlanPars$Fmin<-0.05
ManagementPlanPars$Btrigger<-3184
ManagementPlanPars$Blim<-2500
ManagementPlanPars$Bpa<-NULL
ManagementPlanPars$Fmsy<-0.157
ManagementPlanPars$Flim<-NULL
ManagementPlanPars$Fpa<-0.14
ManagementPlanPars$type<-"MP"

####################################################

# source('bootstrap/utils/utils.R')
# source('bootstrap/model/ProjectionProgs.R')
# source('bootstrap/model/SimProgs2.R')
# source('bootstrap/model/myplot.R')


source('bootstrap/utils/ForecastUtils.R')


#How many years ahead?
np<-10
#How many replicates
n<-1000

Flim<-c(0.235,0.291)
Fpa<-c(0.183,0.227)
Fp05<-c(0.085,0.157)


#Force catch in assessmentyear to be equal sum of national quotas
forceC<-T





#-----------------------------------------------------------#
#FORECAST OPTIONS
#-----------------------------------------------------------#

# XSAMdataobj$Fbarmaxage<-12
data$Fbarmaxage<-12



#MANAGEMENTPLAN
XSAMForecastFMP<-DoXSAMForecast(dataobj=data,
                                fitobj=XSAMfit,
                                parobj=XSAMpars,
                                StochasticForcast=T,
                                Bpars=NULL,
                                Fbarrange=NULL,
                                np=np,n=n,
                                ManagementPlanPars,
                                BparsType=2,
                                weightedF=T,
                                forceC=forceC)



objMP<-ManagementOptionsTable(XSAMForecastFMP,data,weightedF=T)
printManagementOptionsTable(objMP,printBasis=T)


advice <- c()
advice$Variable <- c()
advice$Value <- c()
advice$Notes <- c()


advice$Variable<-c(advice$Variable,'F ages 5-12+ (2019)')
advice$Value <- c(advice$Value,toString(round(objMP$basis$F,digits = 3)))
advice$Notes <- c(advice$Notes,'Based on ICES estimated catches in 2018')


advice$Variable<-c(advice$Variable,'SSB (2019)')
advice$Value <- c(advice$Value,toString(round(objMP$basis$SSB*1000)))
advice$Notes <- c(advice$Notes,'From assessment model')


advice$Variable<-c(advice$Variable,'R age 2 (2019)')
advice$Value <- c(advice$Value,paste0(toString(round(objMP$basis$R[1]/1000,digits = 3)),' billion'))
advice$Notes <- c(advice$Notes,'From assessment model')


advice$Variable<-c(advice$Variable,'R age 2 (2020)')
advice$Value <- c(advice$Value,paste0(toString(round(objMP$basis$R[2]/1000,digits = 3)),' billion'))
advice$Notes <- c(advice$Notes,'Median stochastic recruitment based on the years 1988-2018.')


advice$Variable<-c(advice$Variable,'Catch(2019')
advice$Value <- c(advice$Value,paste0(toString(data$CatchPrediction[1]*1000), ' t'))
advice$Notes <- c(advice$Notes,'Sum of declared unilateral quotas')


write.csv(x=as.data.frame(advice),file = 'output/advice_tab2.csv')








advice <- c()
advice$Basis <- c()
advice$'Total catch (2020)'<-c()
advice$'Fw (2020)'<-c()
advice$'SSB (2020)'<-c()
advice$'%SSB change'<-c()
advice$'%Catch change'<-c()
advice$'% Advice change'<-c()



advice$Basis <- c(advice$Basis,'ICES advice basis')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)','')
advice$'Fw (2020)'<-c(advice$'Fw (2020)','')
advice$'SSB (2020)'<-c(advice$'SSB (2020)','')
advice$'%SSB change'<-c(advice$'%SSB change','')
advice$'%Catch change'<-c(advice$'%Catch change','')
advice$'% Advice change'<-c(advice$'% Advice change','')








advice$Basis <- c(advice$Basis,'Agreed management plan')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objMP$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objMP$optionstab$F,digits = 2))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objMP$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objMP$optionstab$SSB-objMP$basis$SSB)/objMP$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objMP$optionstab$TAC*1000-as.numeric(objMP$basis$TAC)*1000)/(as.numeric(objMP$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objMP$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)






advice$Basis <- c(advice$Basis,'Other scenarios')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)','')
advice$'Fw (2020)'<-c(advice$'Fw (2020)','')
advice$'SSB (2020)'<-c(advice$'SSB (2020)','')
advice$'%SSB change'<-c(advice$'%SSB change','')
advice$'%Catch change'<-c(advice$'%Catch change','')
advice$'% Advice change'<-c(advice$'% Advice change','')









ManagementPlanPars$type<-"MSY"
ManagementPlanPars$Btrigger<-3184
ManagementPlanPars$Fmsy<-0.157
XSAMForecastFMSY1<-DoXSAMForecast(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)

objFMSY1<-ManagementOptionsTable(XSAMForecastFMSY1,data,weightedF=T)
printManagementOptionsTable(objFMSY1,printBasis=T)





advice$Basis <- c(advice$Basis,'MSY approach: FMSY')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objFMSY1$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objFMSY1$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objFMSY1$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objFMSY1$optionstab$SSB-objFMSY1$basis$SSB)/objFMSY1$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objFMSY1$optionstab$TAC*1000-as.numeric(objFMSY1$basis$TAC)*1000)/(as.numeric(objFMSY1$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objFMSY1$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)







ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-0
XSAMForecastFF0<-DoXSAMForecast(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)

objF0<-ManagementOptionsTable(XSAMForecastFF0,data,weightedF=T)
printManagementOptionsTable(objF0,printBasis=T)


advice$Basis <- c(advice$Basis,'F = 0')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objF0$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objF0$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objF0$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objF0$optionstab$SSB-objF0$basis$SSB)/objF0$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objF0$optionstab$TAC*1000-as.numeric(objF0$basis$TAC)*1000)/(as.numeric(objF0$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objF0$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)







ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-Fpa[2]
XSAMForecastFpa<-DoXSAMForecast(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)

objFpa<-ManagementOptionsTable(XSAMForecastFpa,data,weightedF=T)
printManagementOptionsTable(objFpa,printBasis=T)



advice$Basis <- c(advice$Basis,'Fpa')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objFpa$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objFpa$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objFpa$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objFpa$optionstab$SSB-objFpa$basis$SSB)/objFpa$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objFpa$optionstab$TAC*1000-as.numeric(objFpa$basis$TAC)*1000)/(as.numeric(objFpa$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objFpa$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)








ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-Flim[2]
XSAMForecastFlim<-DoXSAMForecast(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)

objFlim<-ManagementOptionsTable(XSAMForecastFlim,data,weightedF=T)
printManagementOptionsTable(objFlim,printBasis=T)



advice$Basis <- c(advice$Basis,'Flim')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objFlim$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objFlim$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objFlim$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objFlim$optionstab$SSB-objFlim$basis$SSB)/objFlim$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objFlim$optionstab$TAC*1000-as.numeric(objFlim$basis$TAC)*1000)/(as.numeric(objFlim$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objFlim$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)








#Fish in 2020 such that SSB(2021)=Blim----Run manually and iterativiely by changing Fset until it match

ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-0.6376346
XSAMForecastF25<-DoXSAMForecast(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)
objF25<-ManagementOptionsTable(XSAMForecastF25,data,weightedF=T)
printManagementOptionsTable(objF25,printBasis=T)

print(round(1000*(objF25$optionstab$SSB-ManagementPlanPars$Blim)))



advice$Basis <- c(advice$Basis,'SSB (2021) = Blim')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objF25$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objF25$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objF25$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objF25$optionstab$SSB-objF25$basis$SSB)/objF25$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objF25$optionstab$TAC*1000-as.numeric(objF25$basis$TAC)*1000)/(as.numeric(objF25$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objF25$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)






#Fish in 2020 such that SSB(2021)=Bpa----Run manually and iterativiely by changing Fset until it match
ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-0.3156
XSAMForecastFBpa<-DoXSAMForecast(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)
objFBpa<-ManagementOptionsTable(XSAMForecastFBpa,data,weightedF=T)
printManagementOptionsTable(objFBpa,printBasis=T)

print(1000*round((objFBpa$optionstab$SSB-ManagementPlanPars$Btrigger)))




advice$Basis <- c(advice$Basis,'SSB (2021) = Bpa = MSY Btrigger')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objFBpa$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objFBpa$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objFBpa$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objFBpa$optionstab$SSB-objFBpa$basis$SSB)/objFBpa$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objFBpa$optionstab$TAC*1000-as.numeric(objFBpa$basis$TAC)*1000)/(as.numeric(objFBpa$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objFBpa$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)







ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-objMP$basis$F
XSAMForecastFFsq<-DoXSAMForecast(dataobj=data,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)
objFsq<-ManagementOptionsTable(XSAMForecastFFsq,data,weightedF=T)
printManagementOptionsTable(objFsq,printBasis=T)



advice$Basis <- c(advice$Basis,'F = F2019')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objFsq$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objFsq$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objFsq$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objFsq$optionstab$SSB-objFsq$basis$SSB)/objFsq$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objFsq$optionstab$TAC*1000-as.numeric(objFsq$basis$TAC)*1000)/(as.numeric(objFsq$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objFsq$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)






# #Fish with the same F as in 2019
# Fpattern<-XSAMfit$stats$FF[,ncol(XSAMfit$stats$FF)]
# Fpattern<-Fpattern/max(Fpattern)
# Bpars<-SetBpars(XSAMdataobj,n=np,type=2)
# names(Bpars)
# Fmult<-SetFtoC(XSAMdataobj$CatchPrediction[1],XSAMfit$stats$N[,ncol(XSAMfit$stats$FF)],XSAMdataobj$natMor[ncol(XSAMfit$stats$FF),paste(2:12)],Bpars$catchMeanWeight[,"2018"],Fpattern)
# Fsq<-Fpattern*Fmult
# #Vektet 5-11
# Fsq<-sum(Fsq[4:10]*XSAMfit$stats$N[4:10,ncol(XSAMfit$stats$FF)])/sum(XSAMfit$stats$N[4:10,ncol(XSAMfit$stats$FF)])
# #Vektet 5-12
# Fsq<-Fpattern*Fmult
# Fsq<-sum(Fsq[4:11]*XSAMfit$stats$N[4:11,ncol(XSAMfit$stats$FF)])/sum(XSAMfit$stats$N[4:11,ncol(XSAMfit$stats$FF)])
# #ManagementPlanPars$Fset<-XSAMfFt2$stats$FbarW[length(XSAMfFt2$stats$FbarW)]
# ManagementPlanPars$Fset<-Fsq
# XSAMForecastFFsq<-DoXSAMForecast(dataobj=XSAMdataobj,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)
# 
# objFsq<-ManagementOptionsTable(XSAMForecastFFsq,XSAMdataobj,weightedF=T)
# printManagementOptionsTable(objFsq,printBasis=T)




advice$Basis <- c(advice$Basis,'F = F selectivity (2019) ')
advice$'Total catch (2020)'<-c(advice$'Total catch (2020)',round(objFsq$optionstab$TAC*1000))
advice$'Fw (2020)'<-c(advice$'Fw (2020)',round(objFsq$optionstab$F,digits = 3))
advice$'SSB (2020)'<-c(advice$'SSB (2020)',round(objFsq$optionstab$SSB*1000))
advice$'%SSB change'<-c(advice$'%SSB change',round((objFsq$optionstab$SSB-objFsq$basis$SSB)/objFsq$basis$SSB*100))
advice$'%Catch change'<-c(advice$'%Catch change',round((objFsq$optionstab$TAC*1000-as.numeric(objFsq$basis$TAC)*1000)/(as.numeric(objFsq$basis$TAC)*1000)*100))
advice$'% Advice change'<-c(advice$'% Advice change',round((round(objFsq$optionstab$TAC*1000)-TAC)/TAC,digits = 2)*100)










write.csv(x=as.data.frame(advice),file='output/advice_table3.csv')
stop()





ManagementPlanPars$type<-"MSY"
ManagementPlanPars$Fmsy<-0.085
XSAMForecastFMSY2<-DoXSAMForecast(dataobj=XSAMdataobj,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)

objFMSY2<-ManagementOptionsTable(XSAMForecastFMSY2,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objFMSY2,printBasis=T)




ManagementPlanPars$type<-"MSY"
ManagementPlanPars$Fmsy<-0.125
XSAMForecastFMSY3<-DoXSAMForecast(dataobj=XSAMdataobj,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)



ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-0.157
XSAMForecastFFpa1<-DoXSAMForecast(dataobj=XSAMdataobj,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)
objFFpa1<-ManagementOptionsTable(XSAMForecastFFpa1,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objFFpa1,printBasis=T)


ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-0.085
XSAMForecastFFpa2<-DoXSAMForecast(dataobj=XSAMdataobj,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)



ManagementPlanPars$type<-"setF"
ManagementPlanPars$Fset<-0.125
XSAMForecastFFpa3<-DoXSAMForecast(dataobj=XSAMdataobj,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)






# #Fish with the same F as in 2019
# Fpattern<-XSAMfit$stats$FF[,ncol(XSAMfit$stats$FF)]
# Fpattern<-Fpattern/max(Fpattern)
# Bpars<-SetBpars(XSAMdataobj,n=np,type=2)
# names(Bpars)
# Fmult<-SetFtoC(XSAMdataobj$CatchPrediction[1],XSAMfit$stats$N[,ncol(XSAMfit$stats$FF)],XSAMdataobj$natMor[ncol(XSAMfit$stats$FF),paste(2:12)],Bpars$catchMeanWeight[,"2018"],Fpattern)
# Fsq<-Fpattern*Fmult
# #Vektet 5-11
# Fsq<-sum(Fsq[4:10]*XSAMfit$stats$N[4:10,ncol(XSAMfit$stats$FF)])/sum(XSAMfit$stats$N[4:10,ncol(XSAMfit$stats$FF)])
# #Vektet 5-12
# Fsq<-Fpattern*Fmult
# Fsq<-sum(Fsq[4:11]*XSAMfit$stats$N[4:11,ncol(XSAMfit$stats$FF)])/sum(XSAMfit$stats$N[4:11,ncol(XSAMfit$stats$FF)])
# #ManagementPlanPars$Fset<-XSAMfFt2$stats$FbarW[length(XSAMfFt2$stats$FbarW)]
# ManagementPlanPars$Fset<-Fsq
# XSAMForecastFFsq<-DoXSAMForecast(dataobj=XSAMdataobj,fitobj=XSAMfit,parobj=XSAMpars,StochasticForcast=T,Bpars=NULL,Fbarrange=NULL,np=np,n=n,ManagementPlanPars,BparsType=2,weightedF=T,forceC=forceC)







####################
#WRITE TABLES FOR REPORT
#source('bootstrap/model/WriteReports.R')


#Input table:
tmptab<-CreateShortTermPredictionInput(XSAMForecastFMP,XSAMdataobj)
tmptab$out1[,2]<-round(tmptab$out1[,2])
tmptab$out1[,7:9]<-round(tmptab$out1[,7:9],3)

tmptab$out2[,2]<-round(tmptab$out2[,2])
tmptab$out2[,7:9]<-round(tmptab$out2[,7:9],3)

# tablepath<-resultpath
tmpfile<-paste('output/',"PredictionInput.txt",sep="")
write("Input for 2018",tmpfile)
write.table(tmptab$out1,tmpfile,sep=";",quote=F,append=T,row.names=F)
write("Input for 2019 and 2020",tmpfile,append=T)
write.table(tmptab$out2,tmpfile,sep=";",quote=F,append=T,row.names=F)




Forecasts<-list(
XSAMForecastFMP=XSAMForecastFMP,
XSAMForecastFMSY1=XSAMForecastFMSY1,
XSAMForecastFMSY2=XSAMForecastFMSY2,
XSAMForecastFMSY3=XSAMForecastFMSY3,
XSAMForecastFFpa1=XSAMForecastFFpa1,
XSAMForecastFFpa2=XSAMForecastFFpa2,
XSAMForecastFFpa3=XSAMForecastFFpa3,
XSAMForecastFF0=XSAMForecastFF0,
XSAMForecastFFsq=XSAMForecastFFsq,
XSAMForecastF25=XSAMForecastF25
)
save(Forecasts,file=paste('output/',"Forecasts",sep=""))
########-------------------------------------------#######





#REstore forecasts
# load("C:/Users/aanes/Documents/WGWIDE/2018/Results/Forecasts")
load('output/Forecasts')
XSAMForecastFMP<-Forecasts$XSAMForecastFMP
XSAMForecastFMSY1<-Forecasts$XSAMForecastFMSY1
XSAMForecastFMSY2<-Forecasts$XSAMForecastFMSY2
XSAMForecastFMSY3<-Forecasts$XSAMForecastFMSY3
XSAMForecastFFpa1<-Forecasts$XSAMForecastFFpa1
XSAMForecastFFpa2<-Forecasts$XSAMForecastFFpa2
XSAMForecastFFpa3<-Forecasts$XSAMForecastFFpa3
XSAMForecastFF0<-Forecasts$XSAMForecastFF0
XSAMForecastFFsq<-Forecasts$XSAMForecastFFsq
XSAMForecastF25<-Forecasts$XSAMForecastF25

source(paste('bootstrap/model/',"utils.R",sep=""))
source(paste('bootstrap/model/',"ProjectionProgs.R",sep=""))
source(paste('bootstrap/model/',"SimProgs2.R",sep=""))
source(paste('bootstrap/model/',"myplot.R",sep=""))


#-----------------------------------------#
#Look at results....
#-----------------------------------------#

length(XSAMForecastFMP$FCrepl)

hmp<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95)
as.data.frame(hmp)



hR<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="R",p=0.95)
as.data.frame(hR)
colMeans(as.data.frame(hR)[32:42,])

mur<-XSAMfit$tab["rec_loga",1]
s2r<-exp(XSAMfit$tab["logsR2",1])
exp(mur)
exp(mur+0.5*s2r)
#source("C:/Users/aanes/Documents/WGWIDE/2018/FinalAssessment/code/ProjectionProgs.R")

#Extract some stats on SSB
hmp<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95,StatsType=3)
hmsy<-XSAMForecastStats(FC=XSAMForecastFMSY1,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95,StatsType=3)
hfpa<-XSAMForecastStats(FC=XSAMForecastFFpa3,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95,StatsType=3)
hf0<-XSAMForecastStats(FC=XSAMForecastFF0,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95,StatsType=3)
hblim<-XSAMForecastStats(FC=XSAMForecastF25,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95,StatsType=3)


#Compare effect of options on SSB

PlotXSAMForecastStats(hmp,xlab="Year",ylab="SSB",xlim=c(2011,2021),ylim=c(2000,7500),lwd=2)
hmp$years
hmp$ymean
axis(1,at=2011:2021)
lines(c(0,1e4),c(3.184,3.184)*1e3,col="gray",lwd=2,lty=3)
PlotXSAMForecastStats(hmsy,add=T,col=2,lwd=2)
PlotXSAMForecastStats(hfpa,add=T,col=3,lwd=2)
PlotXSAMForecastStats(hf0,add=T,col=4,lwd=2)
PlotXSAMForecastStats(hblim,add=T,col=5,lwd=2)
PlotXSAMForecastStats(hmp,add=T,col=1,lwd=2)
legend("bottomleft",lty=1,legend=c("MP","MSY",expression(F==F[pa]),"F=0",expression(B[lim])),title="Rationale:",col=1:5,bty="n",lwd=2)
#lines(c(0,1e4),c(5,5)*1e3,col="gray",lwd=2,lty=3)





#############
#Extract some stats on F
hmp<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95,StatsType=3)
hmsy<-XSAMForecastStats(FC=XSAMForecastFMSY1,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95,StatsType=3)
hfpa<-XSAMForecastStats(FC=XSAMForecastFFpa3,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95,StatsType=3)
hf0<-XSAMForecastStats(FC=XSAMForecastFF0,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95,StatsType=3)
hblim<-XSAMForecastStats(FC=XSAMForecastF25,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95,StatsType=3)

PlotXSAMForecastStats(hmp,xlab="Year",ylab="F",xlim=c(2011,2021),ylim=c(0,0.5),lwd=2)
axis(1,at=2011:2021)
lines(c(0,1e4),c(.125,.125),col="gray",lwd=2,lty=3)
PlotXSAMForecastStats(hmsy,add=T,col=2,lwd=2)
PlotXSAMForecastStats(hfpa,add=T,col=3,lwd=2)
PlotXSAMForecastStats(hf0,add=T,col=4,lwd=2)
PlotXSAMForecastStats(hblim,add=T,col=5,lwd=2)
PlotXSAMForecastStats(hmp,add=T,col=1,lwd=2)
legend("bottomleft",lty=1,legend=c("MP","MSY",expression(F==F[pa]),"F=0",expression(B[lim])),title="Rationale:",col=1:5,bty="n",lwd=2)




#############
#Plott til rapport
#########
png('output/Forecast_trends.png')
par(mfrow=c(1,2),pty='s')
xlim<-c(1989,2021)
hmp<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95)
PlotXSAMForecastStats(hmp,xlab="Year",ylab="SSB",xlim=xlim,ylim=c(0,8500),lwd=2)
axis(1,at=xlim[1]:xlim[2],labels=rep("",length(xlim[1]:xlim[2])))
lines(c(2020,2020),c(0,1e10),col="gray")
lines(c(2020,2020),c(0,1e10),col="gray")

xlim<-c(1989,2021)
hmp<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95)
as.data.frame(hmp)
PlotXSAMForecastStats(hmp,xlab="Year",ylab=expression(bar(F)[5-11]),xlim=xlim,ylim=c(0,.3),lwd=2)
axis(1,at=xlim[1]:xlim[2],labels=rep("",length(xlim[1]:xlim[2])))
lines(c(2020,2020),c(0,1e10),col="gray")
lines(c(2020,2020),c(0,1e10),col="gray")

dev.off()


############# F=0.125, no Btrigger
par(mfrow=c(1,2),pty='s')
xlim<-c(1989,2021)
hmp<-XSAMForecastStats(FC=XSAMForecastFFpa3,fitobj=XSAMfit,dataobj=XSAMdataobj,what="ssb",p=0.95)
PlotXSAMForecastStats(hmp,xlab="Year",ylab="SSB",xlim=xlim,ylim=c(0,8500),lwd=2)
#lines(hmp$years,hmp$ydet0,col=2)
axis(1,at=xlim[1]:xlim[2],labels=rep("",length(xlim[1]:xlim[2])))
lines(c(2020,2020),c(0,1e10),col="gray")
lines(c(2020,2020),c(0,1e10),col="gray")

xlim<-c(1988,2020)
hmp<-XSAMForecastStats(FC=XSAMForecastFFpa3,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95)
as.data.frame(hmp)
PlotXSAMForecastStats(hmp,xlab="Year",ylab=expression(bar(F)[w5-12]),xlim=xlim,ylim=c(0,.3),lwd=2)
#lines(hmp$years,hmp$ydet0,col=2)
axis(1,at=xlim[1]:xlim[2],labels=rep("",length(xlim[1]:xlim[2])))
lines(c(2020,2020),c(0,1e10),col="gray")
lines(c(2020,2020),c(0,1e10),col="gray")
#lines(c(0,1e5),c(0.125,0.125))
#########





#################
#The managementplan
objMP<-ManagementOptionsTable(XSAMForecastFMP,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objMP,printBasis=T)

#AND THE OTHER OPTIONS
objMSY1<-ManagementOptionsTable(XSAMForecastFMSY1,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objMSY1,printBasis=T)

objMSY2<-ManagementOptionsTable(XSAMForecastFMSY2,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objMSY2,printBasis=T)

objMSY3<-ManagementOptionsTable(XSAMForecastFMSY3,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objMSY3,printBasis=T)

objFFpa1<-ManagementOptionsTable(XSAMForecastFFpa1,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objFFpa1,printBasis=T)

objFFpa2<-ManagementOptionsTable(XSAMForecastFFpa2,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objFFpa2,printBasis=T)

objFFpa3<-ManagementOptionsTable(XSAMForecastFFpa3,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objFFpa3,printBasis=T)

objFF0<-ManagementOptionsTable(XSAMForecastFF0,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objFF0,printBasis=T)

objFsq<-ManagementOptionsTable(XSAMForecastFFsq,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objFsq,printBasis=T)

objF25<-ManagementOptionsTable(XSAMForecastF25,XSAMdataobj,weightedF=T)
printManagementOptionsTable(objF25,printBasis=T)





#Dette er til \E5 sl\E5 opp i tabell
  #MP
printManagementOptionsTable(objMP,printBasis=T)
  #
printManagementOptionsTable(objMSY1,printBasis=T)
printManagementOptionsTable(objMSY2,printBasis=T)
printManagementOptionsTable(objMSY3,printBasis=T)
printManagementOptionsTable(objFFpa1,printBasis=T)
printManagementOptionsTable(objFFpa2,printBasis=T)
printManagementOptionsTable(objFFpa3,printBasis=T)
printManagementOptionsTable(objFF0,printBasis=T)
printManagementOptionsTable(objFsq,printBasis=T)
printManagementOptionsTable(objF25,printBasis=T)	
printManagementOptionsTable(objFBpa,printBasis=T)




#Dette er i riktig rekkef\F8lge i tabell

printManagementOptionsTable(objMP,printBasis=T)
printManagementOptionsTable(objFsq,printBasis=T)

printManagementOptionsTable(objMSY2,printBasis=T)
printManagementOptionsTable(objMSY3,printBasis=T)
printManagementOptionsTable(objMSY1,printBasis=T)
printManagementOptionsTable(objFBpa,printBasis=T)
printManagementOptionsTable(objF25,printBasis=T)	


#Some results and plots
hmp<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95)
as.data.frame(hmp)

hmp<-XSAMForecastStats(FC=XSAMForecastFFpa1,fitobj=XSAMfit,dataobj=XSAMdataobj,what="FbarW",p=0.95)
as.data.frame(hmp)

hmp<-XSAMForecastStats(FC=XSAMForecastFMP,fitobj=XSAMfit,dataobj=XSAMdataobj,what="R",p=0.95)
as.data.frame(hmp)


#####################
y<-XSAMForecastFMP$FC0$years
y<-y[1:(length(y)-1)]
XSAMForecastFMP$FC0$FF[,y==2017]
XSAMForecastFMSY1$FC0$FF[,y==2017]

x1<-XSAMForecastFMP$FC0$FF[,y==2018]
x2<-XSAMForecastFMSY1$FC0$FF[,y==2018]
x1/max(x1)
x2/max(x2)

x1<-XSAMForecastFMP$FC0$FF[,y==2019]
x2<-XSAMForecastFMSY1$FC0$FF[,y==2019]
x1/max(x1)
x2/max(x2)


#Deterministic test:

N17<-XSAMForecastFMP$FC0$N[,y==2017]
F17<-XSAMForecastFMP$FC0$FF[,y==2017]
sw17<-XSAMForecastFMP$Bpars$stockMeanWeight[,'2017']
pm17<-XSAMForecastFMP$Bpars$propMat[,'2017']

ssb17<-sum(N17*sw17*pm17)
cbind(XSAMForecastFMP$FC0$years,XSAMForecastFMP$FC0$SSB)
ssb17


XSAMForecastFMP$FC0$N[,y==2018]
XSAMForecastFMSY1$FC0$N[,y==2018]

N18<-c(XSAMForecastFMP$FC0$N[1,y==2018],N17[1:10]*exp(-XSAMForecastFMP$Bpars$M[1:10,'2017']-F17[1:10]))
N18[11]<-N18[11]+N17[11]*exp(-0.15-F17[11])
N18
sw18<-XSAMForecastFMP$Bpars$stockMeanWeight[,'2018']
pm18<-XSAMForecastFMP$Bpars$propMat[,'2018']
ssb18<-sum(N18*sw18*pm18)
#seleksjon i 2018
Fs18<-XSAMForecastFMP$FC0$FF[,y==2018]
Fs18<-Fs18/max(Fs18)

#Skaler F i 2018 slik at fangsten blir 546.448
Fmult18<-SetFtoC(546.448,N18,XSAMForecastFMP$Bpars$M[1:11,'2018'],XSAMForecastFMP$Bpars$catchMeanWeight[,'2018'],Fs18)
F18<-Fmult18*Fs18

x1<-XSAMForecastFMP$FC0$FF[,y==2018]
x2<-XSAMForecastFMSY1$FC0$FF[,y==2018]#:DENNE ER FEIL!!
F18
x1
x2


N19<-c(XSAMForecastFMP$FC0$N[1,y==2020],N18[1:10]*exp(-XSAMForecastFMP$Bpars$M[1:10,'2018']-F18[1:10]))
N19[11]<-N19[11]+N18[11]*exp(-0.15-F18[11])
N19
sw19<-XSAMForecastFMP$Bpars$stockMeanWeight[,'2020']
pm19<-XSAMForecastFMP$Bpars$propMat[,'2020']
ssb19<-sum(N19*sw19*pm19)

####







#--------------------------------------------#
#Look at selection
#--------------------------------------------#

y<-XSAMForecastFMP$years
y<-y[1:(length(y)-1)]


x<-XSAMForecastFMP$FC0$FF[,y==2014]
tmpx<-tmpx1<-NULL
png('output/forecast_selection.png')
plot(2:12,x/max(x),type="l",xlab="Age",ylab="Selection")
for(yy in 1988:2021){
	x<-XSAMForecastFMP$FC0$FF[,y==yy]
	lines(2:12,x/max(x),type="l",col="gray")
	tmpx<-rbind(tmpx,x)
	tmpx1<-rbind(tmpx1,x/max(x))
}
tmpx
tmpyrs<-1988:2020
#msel<-colMeans(tmpx[tmpyrs<=2017,])
x
msel<-colMeans(tmpx[tmpyrs<=2017,])
msel1<-colMeans(tmpx1[tmpyrs<=2017,])
msel1<-msel1/max(msel1)

lines(2:12,msel/max(msel),lwd=3,col="darkgray")
#lines(2:12,msel1/max(msel1),lwd=2)
x<-XSAMForecastFMP$FC0$FF[,y==2014]
lines(2:12,x/max(x),lwd=2,col=1)
x<-XSAMForecastFMP$FC0$FF[,y==2015]
lines(2:12,x/max(x),type="l",col=2,lwd=2)
x<-XSAMForecastFMP$FC0$FF[,y==2016]
lines(2:12,x/max(x),type="l",col=3,lwd=2)
x<-XSAMForecastFMP$FC0$FF[,y==2017]
lines(2:12,x/max(x),type="l",col=4,lwd=2)
x<-XSAMForecastFMP$FC0$FF[,y==2018]
lines(2:12,x/max(x),type="l",col=5,lwd=2)
x<-XSAMForecastFMP$FC0$FF[,y==2019]
lines(2:12,x/max(x),type="l",col=6,lwd=2)
x<-XSAMForecastFMP$FC0$FF[,y==2020]
lines(2:12,x/max(x),type="l",col=7,lwd=2)


legend("topleft",lty=1,legend=paste(2014:2020),title="Years:",col=1:7,bty="n")
dev.off()








